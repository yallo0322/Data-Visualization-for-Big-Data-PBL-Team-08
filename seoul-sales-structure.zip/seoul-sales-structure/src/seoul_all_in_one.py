# ============================================================
# 서울 상권의 매출 구조와 이후 폐업률 분석
#
# 할 일:
# ZIP 읽기 → 검사 → 합치기 → 변수 만들기 → 그림 그리기
# → 패널 분석 → 미래 예측 비교 → 결과 ZIP 다운로드
#
# 중요한 약속:
# 1. 없는 매출을 0원으로 만들지 않아요.
# 2. 사라진 행을 폐업했다고 간주하지 않아요.
# 3. 미래 자료로 과거의 변수를 만들지 않아요.
# 4. 상권 전체의 관계를 개별 가게의 생존확률이라고 부르지 않아요.
# ============================================================

from pathlib import Path
from datetime import datetime
import io
import re
import gc
import json
import zipfile
import hashlib
import traceback

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import koreanize_matplotlib

import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests

from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)

from PIL import Image


# ------------------------------------------------------------
# 0. 설정: 처음에는 그대로 두어도 괜찮아요.
# ------------------------------------------------------------

SEED = 42
DPI = 650                     # 요청한 600dpi보다 높게 저장해요.
MIN_STORES = 5                # 너무 적은 점포의 비율은 쉽게 출렁여요.
BOOTSTRAPS = 400              # 불확실성을 살펴보는 반복 횟수예요.
PREDICTION_HORIZON = 2        # 두 분기 뒤 폐업률을 예측해요.
RUN_PANEL_MODEL = True
RUN_PREDICTION = True
RUN_AREA_HOLDOUT = True

# 결합된 분석용 원자료 사본(수십만 행)을 결과 ZIP에 넣을지 정해요.
# 뒤 분석에는 쓰이지 않는 백업용이라 기본값은 False예요. True면 시간이 오래 걸려요.
SAVE_BIG_DATA = False

# 특정 업종만 보고 싶으면 이름 일부를 적어요.
# 예: "커피", "한식", "미용"
# 빈 문자열이면 전체 업종을 분석해요.
FOCUS_INDUSTRY = ""

assert DPI >= 600

rng = np.random.default_rng(SEED)

ROOT = Path("/content") if Path("/content").exists() else Path.cwd()
RAW = ROOT / "seoul_raw_zip"
RAW.mkdir(parents=True, exist_ok=True)

stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
OUT = ROOT / f"seoul_structure_results_{stamp}"

for folder in ["data", "tables", "figures", "code"]:
    (OUT / folder).mkdir(parents=True, exist_ok=True)

# 지금 실행하는 코드도 결과물에 넣기 위해 기억해 둬요.
try:
    MAIN_SOURCE = get_ipython().history_manager.input_hist_raw[-1]
except Exception:
    MAIN_SOURCE = (
        Path(__file__).read_text(encoding="utf-8")
        if "__file__" in globals()
        else ""
    )

STATUS = []
QUALITY = []
MANIFEST = []
COLUMN_MAP = []
PROFILES = []
FIGURES = []


def save_table(df, name, folder="tables"):
    """엑셀에서도 한글이 잘 보이도록 표를 저장해요."""
    path = OUT / folder / name
    df.to_csv(path, index=False, encoding="utf-8-sig")
    return path


def record_quality(dataset, check, count, explanation):
    QUALITY.append({
        "dataset": dataset,
        "check": check,
        "count": int(count),
        "explanation": explanation,
    })


def record_status(step, status, message=""):
    STATUS.append({
        "step": step,
        "status": status,
        "message": str(message),
    })
    print(f"[{status}] {step}: {message}")


def divide(a, b):
    """분모가 0이면 억지로 나누지 않고 빈칸으로 남겨요."""
    if isinstance(b, pd.Series):
        b = b.where(b > 0)
    else:
        b = np.where(np.asarray(b) > 0, b, np.nan)
    return a / b


def qcode_from_t(t):
    """계산용 분기 번호를 20241 같은 원래 형식으로 돌려요."""
    t = np.asarray(t)
    return (t // 4) * 10 + (t % 4) + 1


# ------------------------------------------------------------
# 1. ZIP 업로드
# ------------------------------------------------------------

zip_paths = sorted(RAW.glob("*.zip"))

if not zip_paths:
    try:
        from google.colab import files
    except ImportError as e:
        raise RuntimeError(
            f"코랩이 아니라면 원본 ZIP을 {RAW} 폴더에 넣고 다시 실행해 주세요."
        ) from e

    print("원본 ZIP 10개(추정매출 5개 + 점포 5개)를 한꺼번에 선택해 주세요.")
    uploaded = files.upload()

    for name, content in uploaded.items():
        if name.lower().endswith(".zip"):
            (RAW / Path(name).name).write_bytes(content)

    del uploaded
    gc.collect()
    zip_paths = sorted(RAW.glob("*.zip"))

if not zip_paths:
    raise ValueError("업로드된 ZIP이 없어요.")

print(f"읽을 ZIP: {len(zip_paths)}개")


# ------------------------------------------------------------
# 2. 열 이름 통일
#
# 어떤 파일은 한글, 어떤 파일은 영문 열 이름을 쓸 수 있어요.
# 같은 뜻의 이름을 한 가지 이름으로 바꿔요.
# 모르는 형식이면 조용히 넘어가지 않고 알려드려요.
# ------------------------------------------------------------

def normalize_name(x):
    return re.sub(
        r"[^0-9A-Z가-힣]",
        "",
        str(x).replace("\ufeff", "").strip().upper(),
    )


ALIAS = {}


def register(target, *names):
    for name in (target,) + names:
        ALIAS[normalize_name(name)] = target


register(
    "qcode",
    "기준_년분기_코드",
    "기준_년_분기_코드",
    "기준년분기코드",
    "STDR_YYQU_CD",
)

register("area_type", "상권_구분_코드", "TRDAR_SE_CD")
register("area_type_name", "상권_구분_코드_명", "TRDAR_SE_CD_NM")
register("area", "상권_코드", "TRDAR_CD")
register("area_name", "상권_코드_명", "TRDAR_CD_NM")
register("industry", "서비스_업종_코드", "SVC_INDUTY_CD")
register("industry_name", "서비스_업종_코드_명", "SVC_INDUTY_CD_NM")

register("sales", "당월_매출_금액", "THSMON_SELNG_AMT")
register("transactions", "당월_매출_건수", "THSMON_SELNG_CO")
register("weekday_sales", "주중_매출_금액", "MDWK_SELNG_AMT")
register("weekend_sales", "주말_매출_금액", "WKEND_SELNG_AMT")

register("stores", "점포_수", "STOR_CO")
register("similar_stores", "유사_업종_점포_수", "SIMILR_INDUTY_STOR_CO")
register("published_open", "개업_율", "개업률", "OPBIZ_RT")
register("opened", "개업_점포_수", "OPBIZ_STOR_CO")
register("published_close", "폐업_률", "폐업률", "CLSBIZ_RT")
register("closed", "폐업_점포_수", "CLSBIZ_STOR_CO")
register("franchise", "프랜차이즈_점포_수", "FRC_STOR_CO")

TIME_NAMES = ["00~06", "06~11", "11~14", "14~17", "17~21", "21~24"]
TIME_HOURS = np.array([6, 5, 3, 3, 4, 3], dtype=float)

for i, label in enumerate(TIME_NAMES):
    start, end = label.split("~")

    register(
        f"time_{i}",
        f"시간대_{label}_매출_금액",
        f"TMZON_{start}_{end}_SELNG_AMT",
    )

    # 첨부 파일에서 실제 확인한 특이한 '건수' 열 이름도 받아요.
    register(
        f"time_count_{i}",
        f"시간대_{label}_매출_건수",
        f"시간대_건수~{end}_매출_건수",
        f"TMZON_{start}_{end}_SELNG_CO",
    )

AGE_NAMES = ["10", "20", "30", "40", "50", "60_이상"]

for i, age in enumerate(AGE_NAMES):
    english_age = "60_ABOVE" if i == 5 else age
    register(
        f"age_{i}",
        f"연령대_{age}_매출_금액",
        f"AGRDE_{english_age}_SELNG_AMT",
    )

DAY_NAMES = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"]
DAY_ENGLISH = ["MON", "TUES", "WED", "THUR", "FRI", "SAT", "SUN"]

for i, (ko, en) in enumerate(zip(DAY_NAMES, DAY_ENGLISH)):
    register(f"day_{i}", f"{ko}_매출_금액", f"{en}_SELNG_AMT")

ID_COLS = [
    "qcode", "area_type", "area_type_name",
    "area", "area_name", "industry", "industry_name",
]

KEY = ["area_type", "area", "industry", "t"]


def read_one_csv(blob, source):
    """한글 인코딩을 차례로 확인하면서 CSV를 읽어요."""
    errors = []
    last_columns = []

    for encoding in ["utf-8-sig", "cp949", "euc-kr"]:
        try:
            d = pd.read_csv(
                io.BytesIO(blob),
                encoding=encoding,
                low_memory=False,
            )
        except (UnicodeError, pd.errors.ParserError) as e:
            errors.append(f"{encoding}: {type(e).__name__}")
            continue

        original = list(d.columns)
        renamed = [
            ALIAS.get(normalize_name(c), str(c).strip())
            for c in original
        ]

        last_columns = original

        if "qcode" not in renamed:
            continue

        d.columns = renamed

        if d.columns.duplicated().any():
            raise ValueError(f"{source}: 같은 의미로 중복된 열 이름이 있어요.")

        for before, after in zip(original, renamed):
            COLUMN_MAP.append({
                "source": source,
                "original_column": before,
                "analysis_column": after,
            })

        return d, encoding

    raise ValueError(
        f"\n파일 형식을 인식하지 못했어요: {source}\n"
        f"확인한 열 이름: {last_columns}\n"
        "이 파일의 기준 분기 열 이름을 ALIAS에 추가해야 해요.\n"
        f"읽기 오류: {errors}"
    )


def profile_columns(d, source, kind):
    """각 열에 빈칸이나 이상한 숫자가 얼마나 있는지 적어요."""
    for c in d.columns:
        s = d[c]
        row = {
            "source": source,
            "kind": kind,
            "column": c,
            "rows": len(s),
            "dtype": str(s.dtype),
            "missing": int(s.isna().sum()),
            "missing_rate": float(s.isna().mean()),
            "unique": int(s.nunique(dropna=True)),
        }

        if pd.api.types.is_numeric_dtype(s):
            good = s.dropna()
            if len(good):
                row.update({
                    "min": good.min(),
                    "p01": good.quantile(0.01),
                    "median": good.median(),
                    "mean": good.mean(),
                    "p99": good.quantile(0.99),
                    "max": good.max(),
                    "zero": int(good.eq(0).sum()),
                    "negative": int(good.lt(0).sum()),
                })
        else:
            row["top3"] = json.dumps(
                s.astype("string").value_counts().head(3).to_dict(),
                ensure_ascii=False,
            )

        PROFILES.append(row)


parts = {"sales": [], "stores": []}

for path in zip_paths:
    with zipfile.ZipFile(path) as z:
        members = [
            n for n in z.namelist()
            if n.lower().endswith(".csv")
            and not n.startswith("__MACOSX/")
        ]

        for member in members:
            source = f"{path.name}::{member}"
            blob = z.read(member)

            d, encoding = read_one_csv(blob, source)

            if "sales" in d.columns:
                kind = "sales"
                required = (
                    ["qcode", "area_type", "area", "industry", "sales"]
                    + [f"time_{i}" for i in range(6)]
                    + [f"age_{i}" for i in range(6)]
                )
            elif "stores" in d.columns:
                kind = "stores"
                required = [
                    "qcode", "area_type", "area", "industry",
                    "stores", "published_close", "closed",
                ]
            else:
                raise ValueError(f"{source}: 매출 또는 점포 자료로 구분할 수 없어요.")

            missing = sorted(set(required) - set(d.columns))
            if missing:
                raise ValueError(f"{source}: 꼭 필요한 열이 없어요: {missing}")

            # 코드는 숫자처럼 보여도 식별표이므로 글자로 보관해요.
            for c in ["area_type", "area", "industry"]:
                d[c] = (
                    d[c].astype("string")
                    .str.strip()
                    .str.replace(r"\.0$", "", regex=True)
                )

            if d[["area_type", "area", "industry"]].isna().any().any():
                raise ValueError(f"{source}: 상권·업종 식별 코드에 빈칸이 있어요.")

            d["qcode"] = pd.to_numeric(d["qcode"], errors="coerce")

            valid_quarter = (
                d["qcode"].notna()
                & d["qcode"].mod(10).isin([1, 2, 3, 4])
                & d["qcode"].between(20001, 21004)
            )

            if not valid_quarter.all():
                raise ValueError(f"{source}: 기준 분기 형식을 확인해 주세요.")

            d["qcode"] = d["qcode"].astype(int)

            # 계산에 쓰는 열만 확실하게 숫자로 바꿔요.
            known_numeric = [
                c for c in d.columns
                if c not in ID_COLS
                and (
                    c in {
                        "sales", "transactions", "weekday_sales", "weekend_sales",
                        "stores", "similar_stores", "published_open",
                        "opened", "published_close", "closed", "franchise",
                    }
                    or c.startswith(("time_", "age_", "day_"))
                )
            ]

            for c in known_numeric:
                original_nonmissing = d[c].notna()
                d[c] = pd.to_numeric(
                    d[c].astype(str).str.replace(",", "", regex=False),
                    errors="coerce",
                )

                failed = original_nonmissing & d[c].isna()
                negative = d[c].lt(0)

                if failed.any():
                    record_quality(
                        kind, f"{c}: numeric_conversion",
                        failed.sum(), source,
                    )

                if negative.any():
                    record_quality(
                        kind, f"{c}: negative_to_missing",
                        negative.sum(),
                        "음수 원자료는 계산용 표에서 결측으로 변경: " + source,
                    )
                    d.loc[negative, c] = np.nan

            for c in ["published_close", "published_open"]:
                if c in d:
                    bad = d[c].gt(100)
                    if bad.any():
                        record_quality(
                            kind, f"{c}: above_100",
                            bad.sum(), source,
                        )
                        d.loc[bad, c] = np.nan

            for c in ["area_name", "industry_name", "area_type_name"]:
                if c not in d:
                    fallback = {
                        "area_name": "area",
                        "industry_name": "industry",
                        "area_type_name": "area_type",
                    }[c]
                    d[c] = d[fallback]

            profile_columns(d, source, kind)

            MANIFEST.append({
                "source": source,
                "kind": kind,
                "rows": len(d),
                "columns": len(d.columns),
                "encoding": encoding,
                "min_quarter": int(d["qcode"].min()),
                "max_quarter": int(d["qcode"].max()),
                "csv_sha256": hashlib.sha256(blob).hexdigest(),
            })

            d["year"] = d["qcode"] // 10
            d["quarter"] = d["qcode"] % 10
            d["t"] = d["year"] * 4 + d["quarter"] - 1
            d["source"] = source
            parts[kind].append(d)

            print(f"읽었어요: {kind}, {len(d):,}행, {member}")

            del blob
            gc.collect()


def combine_clean(frames, kind):
    if not frames:
        raise ValueError(f"{kind} 자료가 없어요.")

    d = pd.concat(frames, ignore_index=True)

    # 출처만 다른 완전히 같은 행은 한 번만 남겨요.
    compare_cols = [c for c in d if c != "source"]
    before = len(d)
    d = d.drop_duplicates(subset=compare_cols).copy()

    record_quality(
        kind, "exact_duplicates_removed", before - len(d),
        "값이 완전히 같은 중복만 제거했어요.",
    )

    # 같은 상권·업종·분기에 서로 다른 값이 있으면 선택하지 않아요.
    conflict = d.duplicated(KEY, keep=False)

    if conflict.any():
        save_table(d.loc[conflict], f"{kind}_conflicting_keys.csv")
        raise ValueError(
            f"{kind}: 같은 키에 서로 다른 값이 있어요. "
            "conflicting_keys 표를 확인해야 해요."
        )

    d["entity"] = (
        d["area_type"].astype(str) + "|"
        + d["area"].astype(str) + "|"
        + d["industry"].astype(str)
    )
    d["area_key"] = d["area_type"].astype(str) + "|" + d["area"].astype(str)

    return d.sort_values(["entity", "t"]).reset_index(drop=True)


sales = combine_clean(parts["sales"], "sales")
stores = combine_clean(parts["stores"], "stores")

del parts
gc.collect()

for c in [
    "similar_stores", "opened", "franchise",
    "published_open",
]:
    if c not in stores:
        stores[c] = np.nan

for c in ["transactions", "weekday_sales", "weekend_sales"]:
    if c not in sales:
        sales[c] = np.nan

save_table(pd.DataFrame(MANIFEST), "input_manifest.csv")
save_table(pd.DataFrame(COLUMN_MAP), "column_mapping.csv")
save_table(pd.DataFrame(PROFILES), "column_profiles.csv")

coverage = pd.concat([
    sales.groupby("qcode").size().rename("rows").reset_index().assign(dataset="sales"),
    stores.groupby("qcode").size().rename("rows").reset_index().assign(dataset="stores"),
], ignore_index=True)

save_table(coverage, "quarter_coverage.csv")

record_status(
    "파일 통합", "완료",
    f"매출 {len(sales):,}행 / 점포 {len(stores):,}행",
)


# ------------------------------------------------------------
# 3. 폐업률 분모 점검
#
# 주 분석에서는 원자료의 폐업률을 그대로 써요.
# 아래 재계산 값은 '점검용'이지 자동 교체용이 아니에요.
# ------------------------------------------------------------

denominator_results = []

audit = stores.loc[
    stores["closed"].gt(0) & stores["published_close"].notna()
].copy()

candidates = {
    "closed / stores": audit["stores"],
    "closed / similar_stores": audit["similar_stores"],
    "closed / (stores + closed)": audit["stores"] + audit["closed"],
    "closed / (similar_stores + closed)": (
        audit["similar_stores"] + audit["closed"]
    ),
}

for name, denominator in candidates.items():
    estimate = 100 * divide(audit["closed"], denominator)
    err = (estimate - audit["published_close"]).abs().dropna()

    denominator_results.append({
        "candidate": name,
        "rows_compared": len(err),
        "mean_absolute_difference_pp": err.mean(),
        "agreement_within_0_51pp": err.le(0.51).mean(),
        "agreement_within_0_011pp": err.le(0.011).mean(),
        "note": "일치율은 진단값이며 분모의 공식 의미를 증명하지 않음",
    })

save_table(pd.DataFrame(denominator_results), "closure_denominator_audit.csv")

relation_available = stores[
    ["stores", "franchise", "similar_stores"]
].notna().all(axis=1)

relation_bad = relation_available & (
    stores["stores"] + stores["franchise"] != stores["similar_stores"]
)

record_quality(
    "stores",
    "stores_plus_franchise_not_equal_similar",
    relation_bad.sum(),
    "이 관계를 가정하지 않고 실제 값으로 검사했어요.",
)


# ------------------------------------------------------------
# 4. 정확히 이전/이후 분기 자료 붙이기
#
# 그냥 '바로 위 행'을 쓰면 중간에 빠진 분기를 놓칠 수 있어요.
# 달력상 정확히 몇 분기 전·후인지 맞춰 붙여요.
# ------------------------------------------------------------

def shifted_table(d, columns, steps, prefix):
    """
    steps = -4: 작년 같은 분기
    steps =  1: 다음 분기
    steps =  2: 두 분기 뒤
    """
    z = d[KEY + columns].copy()
    z["t"] = z["t"] - steps
    return z.rename(columns={c: f"{prefix}{c}" for c in columns})


for step, tag in [(-1, "prev_"), (-4, "yearago_")]:
    stores = stores.merge(
        shifted_table(stores, ["stores"], step, tag),
        on=KEY, how="left", validate="one_to_one",
    )

stores["store_growth_qoq"] = divide(
    stores["stores"], stores["prev_stores"]
) - 1

stores["store_growth_yoy"] = divide(
    stores["stores"], stores["yearago_stores"]
) - 1

store_columns = [
    "stores", "similar_stores", "opened", "closed",
    "published_open", "published_close", "franchise",
    "store_growth_qoq", "store_growth_yoy",
]

panel = sales.merge(
    stores[KEY + store_columns],
    on=KEY,
    how="left",
    validate="one_to_one",
    indicator=True,
)

record_quality(
    "merge", "sales_without_store_match",
    panel["_merge"].eq("left_only").sum(),
    "매출 자료에 대응하는 점포 행이 없는 경우예요.",
)

save_table(
    panel["_merge"].value_counts().rename_axis("match").reset_index(name="rows"),
    "merge_audit.csv",
)

panel = panel.drop(columns="_merge")

for h in [1, 2, 4]:
    future = shifted_table(
        stores, ["published_close", "closed", "stores"], h, f"h{h}_"
    )
    panel = panel.merge(
        future, on=KEY, how="left", validate="one_to_one",
    )
    panel = panel.rename(columns={
        f"h{h}_published_close": f"close_h{h}",
        f"h{h}_closed": f"closed_count_h{h}",
        f"h{h}_stores": f"stores_h{h}",
    })

for step, tag in [(-1, "prev_"), (-4, "yearago_")]:
    panel = panel.merge(
        shifted_table(sales, ["sales"], step, tag),
        on=KEY, how="left", validate="one_to_one",
    )

panel["sales_growth_qoq"] = divide(panel["sales"], panel["prev_sales"]) - 1
panel["sales_growth_yoy"] = divide(panel["sales"], panel["yearago_sales"]) - 1

# 증가율의 차이이므로 단위는 퍼센트포인트예요.
panel["overheat_qoq_pp"] = 100 * (
    panel["store_growth_qoq"] - panel["sales_growth_qoq"]
)
panel["overheat_yoy_pp"] = 100 * (
    panel["store_growth_yoy"] - panel["sales_growth_yoy"]
)


# ------------------------------------------------------------
# 5. 매출의 '구조' 변수 만들기
#
# HHI:
# 여러 바구니에 돈이 골고루 나뉘면 작아지고,
# 한 바구니에 몰리면 커져요.
# ------------------------------------------------------------

def composition(d, columns):
    a = d[columns].to_numpy(dtype=float)

    valid = (
        np.isfinite(a).all(axis=1)
        & (a >= 0).all(axis=1)
        & (a.sum(axis=1) > 0)
    )

    p = np.full(a.shape, np.nan, dtype=float)
    p[valid] = a[valid] / a[valid].sum(axis=1, keepdims=True)

    total = np.where(valid, a.sum(axis=1), np.nan)
    hhi = np.sum(p ** 2, axis=1)

    with np.errstate(divide="ignore", invalid="ignore"):
        terms = np.where(p > 0, p * np.log(p), 0.0)
    entropy = -terms.sum(axis=1) / np.log(len(columns))
    entropy[~valid] = np.nan

    return p, total, hhi, entropy


time_cols = [f"time_{i}" for i in range(6)]
age_cols = [f"age_{i}" for i in range(6)]

tp, time_total, time_hhi, time_entropy = composition(panel, time_cols)
ap, age_total, age_hhi, age_entropy = composition(panel, age_cols)

panel["time_hhi"] = time_hhi
panel["age_hhi"] = age_hhi

panel["time_entropy"] = time_entropy
panel["age_entropy"] = age_entropy

panel["time_effective_bins"] = 1 / panel["time_hhi"]
panel["age_effective_groups"] = 1 / panel["age_hhi"]

panel["time_duration_concentration"] = (
    np.sum(tp ** 2 / (TIME_HOURS / 24), axis=1) - 1
)

panel["time_coverage"] = divide(pd.Series(time_total, index=panel.index), panel["sales"])
panel["age_coverage"] = divide(pd.Series(age_total, index=panel.index), panel["sales"])

for i in range(6):
    panel[f"time_share_{i}"] = tp[:, i]
    panel[f"age_share_{i}"] = ap[:, i]

panel["time_peak_share"] = np.max(tp, axis=1)
panel["night_share"] = tp[:, 0] + tp[:, 5]
panel["young_adult_share"] = ap[:, 1] + ap[:, 2]
panel["senior_share"] = ap[:, 5]

# 이것은 상호작용항이에요.
# '시간 × 연령' 결합분포의 HHI라고 부르면 안 돼요.
panel["time_age_interaction"] = panel["time_hhi"] * panel["age_hhi"]

count_cols = [f"time_count_{i}" for i in range(6)]

if set(count_cols).issubset(panel.columns):
    _, _, count_hhi, _ = composition(panel, count_cols)
    panel["time_count_hhi"] = count_hhi
    panel["amount_count_hhi_gap"] = (
        panel["time_hhi"] - panel["time_count_hhi"]
    )
else:
    panel["time_count_hhi"] = np.nan
    panel["amount_count_hhi_gap"] = np.nan

day_cols = [f"day_{i}" for i in range(7)]

if set(day_cols).issubset(panel.columns):
    _, _, day_hhi, _ = composition(panel, day_cols)
    panel["day_hhi"] = day_hhi
else:
    panel["day_hhi"] = np.nan

panel["weekend_share"] = divide(panel["weekend_sales"], panel["sales"])

# 분기마다 주말 날짜 수가 조금 달라요.
# 그래서 토·일은 무조건 2일, 평일은 5일이라고 처리하지 않아요.
day_counts = {}

for qcode in panel["qcode"].unique():
    year, quarter = int(qcode // 10), int(qcode % 10)
    period = pd.Period(f"{year}Q{quarter}", freq="Q")
    dates = pd.date_range(period.start_time, period.end_time.normalize())
    weekend_days = int((dates.dayofweek >= 5).sum())
    day_counts[qcode] = (len(dates) - weekend_days, weekend_days)

weekday_n = panel["qcode"].map(lambda q: day_counts[q][0])
weekend_n = panel["qcode"].map(lambda q: day_counts[q][1])

panel["weekend_daily_ratio"] = divide(
    divide(panel["weekend_sales"], weekend_n),
    divide(panel["weekday_sales"], weekday_n),
)

panel["sales_per_store_proxy"] = divide(panel["sales"], panel["stores"])
panel["mean_ticket"] = divide(panel["sales"], panel["transactions"])

panel["franchise_share_proxy"] = divide(
    panel["franchise"], panel["similar_stores"]
)

bad_franchise = ~panel["franchise_share_proxy"].between(0, 1)
panel.loc[bad_franchise, "franchise_share_proxy"] = np.nan

panel["churn_proxy"] = divide(
    panel["opened"] + panel["closed"], panel["stores"]
)
panel["net_entry_proxy"] = divide(
    panel["opened"] - panel["closed"], panel["stores"]
)

# 아래 이름에 proxy가 붙은 이유:
# 점포수의 정확한 포함 범위에 따라 해석이 달라질 수 있기 때문이에요.


# ------------------------------------------------------------
# 6. 과거 4분기 변동성, 구조 변화량
# ------------------------------------------------------------

panel = panel.sort_values(["entity", "t"]).reset_index(drop=True)
g = panel.groupby("entity", sort=False)

continuous_four = panel["t"] - g["t"].shift(3) == 3

for value, result in [
    ("sales", "sales_cv4"),
    ("sales_per_store_proxy", "per_store_cv4"),
]:
    rolling = g[value].rolling(4, min_periods=4)

    rmean = (
        rolling.mean()
        .reset_index(level=0, drop=True)
        .reindex(panel.index)
    )
    rstd = (
        rolling.std(ddof=1)
        .reset_index(level=0, drop=True)
        .reindex(panel.index)
    )

    panel[result] = divide(rstd, rmean).where(continuous_four)

# 전체 기간 CV는 설명용이에요. 예측에는 넣지 않아요.
full_cv = panel.groupby("entity")["sales"].agg(["mean", "std"])
panel["sales_cv_all_descriptive_only"] = panel["entity"].map(
    divide(full_cv["std"], full_cv["mean"])
)

continuous_one = panel["t"] - g["t"].shift(1) == 1

panel["time_hhi_change"] = (
    panel["time_hhi"] - g["time_hhi"].shift(1)
).where(continuous_one)

panel["age_hhi_change"] = (
    panel["age_hhi"] - g["age_hhi"].shift(1)
).where(continuous_one)


def js_change(prefix):
    cols = [f"{prefix}_share_{i}" for i in range(6)]
    now = panel[cols].to_numpy(dtype=float)
    before = g[cols].shift(1).to_numpy(dtype=float)
    midpoint = (now + before) / 2

    with np.errstate(divide="ignore", invalid="ignore"):
        a = np.where(now > 0, now * np.log(now / midpoint), 0)
        b = np.where(before > 0, before * np.log(before / midpoint), 0)

    value = 0.5 * (a.sum(axis=1) + b.sum(axis=1))
    valid = (
        np.isfinite(now).all(axis=1)
        & np.isfinite(before).all(axis=1)
        & continuous_one.to_numpy()
    )
    value[~valid] = np.nan
    return value


panel["time_js_change"] = js_change("time")
panel["age_js_change"] = js_change("age")

# 같은 업종·같은 분기 평균적인 모습과 얼마나 다른지도 봐요.
panel["time_hhi_vs_industry_median"] = (
    panel["time_hhi"]
    - panel.groupby(["industry", "t"])["time_hhi"].transform("median")
)

# 상권의 업종 구성 집중도: 이 파일에 관측된 업종·점포 기준이에요.
area_keys = ["area_type", "area", "t"]

mix = stores[area_keys + ["stores"]].copy()
area_total = mix.groupby(area_keys)["stores"].transform("sum")
mix["square_share"] = divide(mix["stores"], area_total) ** 2

area_mix = (
    mix.groupby(area_keys)["square_share"]
    .sum(min_count=1)
    .rename("area_industry_hhi")
    .reset_index()
)

panel = panel.merge(
    area_mix, on=area_keys, how="left", validate="many_to_one",
)

panel["log_sales"] = np.log1p(panel["sales"])
panel["log_stores"] = np.log1p(panel["stores"])
panel["quarter_sin"] = np.sin(2 * np.pi * panel["quarter"] / 4)
panel["quarter_cos"] = np.cos(2 * np.pi * panel["quarter"] / 4)

# 무한대는 숫자가 아니에요. 계산용 표에서는 결측으로 남겨요.
numeric_cols = panel.select_dtypes(include=np.number).columns
panel[numeric_cols] = panel[numeric_cols].replace([np.inf, -np.inf], np.nan)

record_quality(
    "sales",
    "time_coverage_outside_0_99_to_1_01",
    (~panel["time_coverage"].between(0.99, 1.01)).sum(),
    "시간대 합계가 전체 매출과 약 1% 이상 차이 나는 행이에요.",
)

record_quality(
    "sales",
    "age_coverage_above_1_01",
    panel["age_coverage"].gt(1.01).sum(),
    "연령별 합계가 전체 매출보다 큰 사례를 확인해야 해요.",
)

record_quality(
    "panel",
    "missing_future_h1",
    panel["close_h1"].isna().sum(),
    "미래 행이 없는 것은 폐업했다는 뜻이 아니에요.",
)

if SAVE_BIG_DATA:
    fast_gzip = {"method": "gzip", "compresslevel": 1}   # 압축은 약하게, 속도는 빠르게
    panel.to_csv(OUT / "data" / "analysis_panel.csv.gz", index=False,
                 encoding="utf-8-sig", compression=fast_gzip)
    stores.to_csv(OUT / "data" / "store_panel.csv.gz", index=False,
                  encoding="utf-8-sig", compression=fast_gzip)
else:
    print("[건너뜀] 큰 원자료 사본 저장: 결과 그림·표에는 영향 없음")
save_table(pd.DataFrame(QUALITY), "quality_log.csv")

record_status("변수 생성", "완료", f"분석용 표 {len(panel):,}행")


# ------------------------------------------------------------
# 7. 분석 표본 정하기
#
# 결과가 잘 나오도록 자르는 것이 아니라,
# 미리 정한 품질 조건을 적용해요.
# ------------------------------------------------------------

conditions = [
    ("매출이 양수", panel["sales"].gt(0)),
    ("점포 수 기준", panel["stores"].ge(MIN_STORES)),
    ("시간대 합계 확인", panel["time_coverage"].between(0.99, 1.01)),
    ("시간 HHI 존재", panel["time_hhi"].notna()),
]

if FOCUS_INDUSTRY:
    conditions.append((
        "선택 업종",
        panel["industry_name"].astype(str).str.contains(
            FOCUS_INDUSTRY, regex=False, na=False
        ),
    ))

keep = pd.Series(True, index=panel.index)
flow = [{"step": "시작", "rows": len(panel)}]

for label, condition in conditions:
    keep &= condition.fillna(False)
    flow.append({"step": label, "rows": int(keep.sum())})

analysis = panel.loc[keep].copy()

save_table(pd.DataFrame(flow), "sample_flow.csv")

if analysis.empty:
    raise ValueError("품질 조건을 만족하는 행이 없어요. sample_flow를 확인해 주세요.")

FEATURES = [
    "time_hhi", "age_hhi", "time_duration_concentration",
    "time_entropy", "age_entropy", "time_peak_share",
    "night_share", "day_hhi", "weekend_share", "weekend_daily_ratio",
    "sales_cv4", "per_store_cv4",
    "overheat_qoq_pp", "overheat_yoy_pp",
    "time_js_change", "age_js_change",
    "time_hhi_change", "age_hhi_change",
    "time_count_hhi", "amount_count_hhi_gap",
    "age_coverage", "mean_ticket", "franchise_share_proxy",
    "churn_proxy", "net_entry_proxy", "area_industry_hhi",
]

summary = (
    analysis[FEATURES]
    .describe(percentiles=[0.01, 0.25, 0.5, 0.75, 0.99])
    .T.reset_index()
    .rename(columns={"index": "variable"})
)

save_table(summary, "feature_summary.csv")

# 상관계수는 탐색용이에요.
# 반복 관측의 의존성을 무시한 p값은 붙이지 않아요.
corr = analysis[
    FEATURES + ["published_close", "close_h1", "close_h2"]
].corr(method="spearman")

save_table(
    corr.reset_index().rename(columns={"index": "variable"}),
    "spearman_correlations_descriptive.csv",
)


# ------------------------------------------------------------
# 8. 그림 준비
#
# PNG는 650dpi, PDF도 함께 저장해요.
# 그림에 사용한 숫자도 별도 표로 남겨요.
# ------------------------------------------------------------

COLORS = [
    "#1751D0", "#E2661E", "#0E9E8F", "#C08A00",
    "#D95D8F", "#2E7D32", "#9117D0", "#C1232C",
]

SURFACE = "#FDFDFF"
INK = "#1E2433"
GRID = "#E2E6F0"

SEQ = LinearSegmentedColormap.from_list(
    "seoul_blue",
    ["#E8EEFB", "#C2D3F4", "#8FAEEA", "#4E7FDD", "#1751D0", "#0D317D"],
)

plt.rcParams.update({
    "figure.facecolor": SURFACE,
    "axes.facecolor": SURFACE,
    "text.color": INK,
    "axes.labelcolor": INK,
    "xtick.color": "#505A74",
    "ytick.color": "#505A74",
    "axes.unicode_minus": False,
    "font.size": 11,
    "pdf.fonttype": 42,
})


def style_axis(ax):
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", color=GRID, linewidth=0.7)
    ax.set_axisbelow(True)


def finish_figure(fig, name, note=""):
    fig.tight_layout(rect=(0, 0.08, 1, 1))
    if note:
        fig.text(
            0.02, 0.015, note,
            fontsize=8, color="#505A74", va="bottom",
        )

    png = OUT / "figures" / f"{name}.png"
    pdf = OUT / "figures" / f"{name}.pdf"

    fig.savefig(png, dpi=DPI, bbox_inches="tight", facecolor=SURFACE)
    fig.savefig(pdf, dpi=DPI, bbox_inches="tight", facecolor=SURFACE)
    plt.close(fig)

    with Image.open(png) as im:
        stored_dpi = im.info.get("dpi", (0, 0))
        if min(stored_dpi) < 600:
            raise ValueError(f"{name}: 저장된 해상도를 확인해야 해요.")

    FIGURES.append(name)


def scatter_with_line(d, x, y, name, xlabel, ylabel, trim=False):
    z = d[[x, y, "area_key"]].dropna().copy()

    if len(z) < 30 or z[x].nunique() < 3 or z["area_key"].nunique() < 3:
        return

    # 회귀 계산에는 아래 z 전체를 사용해요.
    # 상권 안에서 관측치들이 닮을 수 있으므로 상권별 군집 표준오차를 써요.
    model = sm.OLS(
        z[y], sm.add_constant(z[[x]], has_constant="add")
    ).fit(
        cov_type="cluster",
        cov_kwds={"groups": z["area_key"].astype(str)},
    )

    lo, hi = (
        z[x].quantile([0.01, 0.99]).to_numpy()
        if trim else np.array([z[x].min(), z[x].max()])
    )

    visible = z[z[x].between(lo, hi)]
    shown = visible.sample(min(10000, len(visible)), random_state=SEED)

    grid = np.linspace(lo, hi, 150)
    X = np.column_stack([np.ones(len(grid)), grid])

    prediction = X @ model.params.to_numpy()
    se = np.sqrt(np.maximum(
        np.einsum("ij,jk,ik->i", X, model.cov_params().to_numpy(), X), 0
    ))

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(
        shown[x], shown[y],
        s=7, alpha=0.13, color=COLORS[0],
        rasterized=True,
    )
    ax.plot(grid, prediction, color=COLORS[1], linewidth=2)
    ax.fill_between(
        grid, prediction - 1.96 * se, prediction + 1.96 * se,
        color=COLORS[1], alpha=0.15,
    )

    ax.set(
        xlabel=xlabel,
        ylabel=ylabel,
        title=f"{xlabel}와 {ylabel}",
    )
    style_axis(ax)

    extra = " / 그림의 x축은 1~99백분위 범위" if trim else ""

    finish_figure(
        fig, name,
        f"단순 관계, 인과효과 아님. 회귀 n={len(z):,}; "
        f"점은 최대 10,000개 표시. 띠는 상권 군집 기준 95% 근사구간.{extra}",
    )

    save_table(shown, f"{name}_shown_points.csv")

    save_table(pd.DataFrame({
        "x": grid,
        "fitted": prediction,
        "lower95": prediction - 1.96 * se,
        "upper95": prediction + 1.96 * se,
    }), f"{name}_line.csv")


scatter_with_line(
    analysis, "time_hhi", "published_close",
    "01_time_hhi_current_closure",
    "시간대 매출 HHI", "같은 분기 제공 폐업률 (%)",
)

scatter_with_line(
    analysis, "time_hhi", "close_h1",
    "02_time_hhi_future_closure",
    "시간대 매출 HHI", "다음 분기 제공 폐업률 (%)",
)


# HHI 구간별 막대그림: 비율을 모두 더하지 않고 행별 평균을 구해요.
bins_data = analysis[
    ["time_hhi", "close_h1", "area_key"]
].dropna().copy()

if len(bins_data) >= 100:
    bins_data["bin"] = pd.qcut(
        bins_data["time_hhi"], 5,
        labels=False, duplicates="drop",
    )
    bins_data = bins_data.dropna(subset=["bin"])
    bins_data["bin"] = bins_data["bin"].astype(int)

    bin_summary = bins_data.groupby("bin").agg(
        mean_closure=("close_h1", "mean"),
        observations=("close_h1", "size"),
        hhi_min=("time_hhi", "min"),
        hhi_max=("time_hhi", "max"),
    )

    # 한 상권의 모든 분기·업종을 묶어서 재추출해요.
    sums = bins_data.pivot_table(
        index="area_key", columns="bin",
        values="close_h1", aggfunc="sum", fill_value=0,
    )
    counts = bins_data.pivot_table(
        index="area_key", columns="bin",
        values="close_h1", aggfunc="count", fill_value=0,
    )

    sums = sums.reindex(columns=bin_summary.index, fill_value=0)
    counts = counts.reindex(index=sums.index, columns=sums.columns, fill_value=0)

    G = len(sums)
    weights = rng.multinomial(G, np.full(G, 1 / G), size=BOOTSTRAPS)

    with np.errstate(divide="ignore", invalid="ignore"):
        boot = (weights @ sums.to_numpy()) / (weights @ counts.to_numpy())

    bin_summary["lower95"] = np.nanquantile(boot, 0.025, axis=0)
    bin_summary["upper95"] = np.nanquantile(boot, 0.975, axis=0)

    x = np.arange(len(bin_summary))
    y = bin_summary["mean_closure"].to_numpy()

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.bar(x, y, color=COLORS[0], width=0.65)

    ax.errorbar(
        x, y,
        yerr=np.vstack([
            np.maximum(y - bin_summary["lower95"].to_numpy(), 0),
            np.maximum(bin_summary["upper95"].to_numpy() - y, 0),
        ]),
        fmt="none", color=INK, capsize=4,
    )

    labels = [
        f"{r.hhi_min:.2f}~{r.hhi_max:.2f}\nn={int(r.observations):,}"
        for r in bin_summary.itertuples()
    ]

    ax.set_xticks(x, labels)
    ax.set(
        xlabel="HHI 분위 구간",
        ylabel="다음 분기 제공 폐업률의 행별 평균 (%)",
        title="시간대 매출 집중도 구간별 이후 폐업률",
    )
    ax.set_ylim(bottom=0)
    style_axis(ax)

    finish_figure(
        fig, "03_hhi_bins_future_closure",
        "오차막대: 상권 단위 부트스트랩 95% 구간. "
        "점포 수로 가중한 서울 전체 폐업률이 아니라 상권×업종×분기 평균이에요.",
    )

    save_table(bin_summary.reset_index(), "03_hhi_bins_table.csv")


# 시간 집중도와 연령 집중도를 함께 살펴봐요.
joint = analysis[["time_hhi", "age_hhi", "close_h1"]].dropna().copy()

if len(joint) >= 100:
    joint["time_bin"] = pd.qcut(
        joint["time_hhi"], 4, labels=False, duplicates="drop"
    )
    joint["age_bin"] = pd.qcut(
        joint["age_hhi"], 4, labels=False, duplicates="drop"
    )

    jt = joint.groupby(["time_bin", "age_bin"]).agg(
        mean_closure=("close_h1", "mean"),
        n=("close_h1", "size"),
    ).reset_index()

    mat = jt.pivot(
        index="age_bin", columns="time_bin", values="mean_closure"
    )
    nmat = jt.pivot(index="age_bin", columns="time_bin", values="n")
    shown_mat = mat.where(nmat >= 30)

    fig, ax = plt.subplots(figsize=(7, 5))
    im = ax.imshow(shown_mat, cmap=SEQ, origin="lower", aspect="auto")

    for row in range(len(mat.index)):
        for col in range(len(mat.columns)):
            if pd.notna(shown_mat.iloc[row, col]):
                ax.text(
                    col, row,
                    f"{mat.iloc[row, col]:.2f}%\nn={int(nmat.iloc[row, col]):,}",
                    ha="center", va="center", fontsize=9,
                    bbox=dict(facecolor="white", alpha=0.8, edgecolor="none"),
                )

    ax.set_xticks(range(len(mat.columns)), [f"{int(i)+1}분위" for i in mat.columns])
    ax.set_yticks(range(len(mat.index)), [f"{int(i)+1}분위" for i in mat.index])
    ax.set(
        xlabel="시간대 HHI: 오른쪽으로 갈수록 집중",
        ylabel="연령대 HHI: 위로 갈수록 집중",
        title="두 가지 집중도가 함께 높으면 이후 폐업률은 어떨까요?",
    )
    fig.colorbar(im, ax=ax, label="다음 분기 평균 제공 폐업률 (%)")

    finish_figure(
        fig, "04_time_age_joint_pattern",
        "상호작용 탐색용 그림. n<30 구간은 표시하지 않아요. "
        "시간×연령 결합 매출분포를 관측한 것은 아니에요.",
    )
    save_table(jt, "04_time_age_joint_table.csv")


# 주요 변수의 분포
fig, axes = plt.subplots(2, 2, figsize=(10, 7))
hist_rows = []

for ax, variable, title in zip(
    axes.flat,
    ["time_hhi", "age_hhi", "sales_cv4", "overheat_yoy_pp"],
    ["시간대 HHI", "연령대 HHI", "최근 4분기 매출 CV", "전년동기 과열 신호 (%p)"],
):
    values = analysis[variable].dropna()
    if len(values):
        lo, hi = values.quantile([0.01, 0.99])
        visible = values[values.between(lo, hi)]
        counts, edges = np.histogram(visible, bins=35)

        ax.hist(visible, bins=edges, color=COLORS[0], alpha=0.9)
        ax.set(title=title, xlabel=title, ylabel="관측 행 수")
        style_axis(ax)

        for i, count in enumerate(counts):
            hist_rows.append({
                "variable": variable,
                "left": edges[i],
                "right": edges[i+1],
                "count": count,
            })

finish_figure(
    fig, "05_feature_distributions",
    "그림은 각 변수의 1~99백분위 범위를 표시해요. "
    "원자료와 전체 요약통계에서는 꼬리를 삭제하지 않아요.",
)
save_table(pd.DataFrame(hist_rows), "05_histogram_values.csv")


# 업종별 시간대 매출 비중
top_industries = analysis["industry_name"].value_counts().head(12).index

profiles = (
    analysis[analysis["industry_name"].isin(top_industries)]
    .groupby("industry_name")[[f"time_share_{i}" for i in range(6)]]
    .mean()
    .reindex(top_industries)
)

fig, ax = plt.subplots(figsize=(9, 7))
im = ax.imshow(profiles.to_numpy(), cmap=SEQ, aspect="auto")
ax.set_xticks(range(6), TIME_NAMES)
ax.set_yticks(range(len(profiles)), profiles.index)
ax.set(
    xlabel="시간대", ylabel="업종",
    title="업종마다 매출이 모이는 시간이 달라요",
)
fig.colorbar(im, ax=ax, label="상권×분기별 매출 비중의 평균")

finish_figure(
    fig, "06_industry_time_profiles",
    "관측 행 수가 많은 12개 업종. 매출액 가중 평균이 아닌 관측 행별 평균이에요.",
)
save_table(profiles.reset_index(), "06_industry_time_profiles.csv")


# 분기별 집중도 변화
trend = analysis.groupby("qcode").agg(
    time_hhi=("time_hhi", "mean"),
    age_hhi=("age_hhi", "mean"),
    observations=("time_hhi", "size"),
).reset_index()

fig, ax = plt.subplots(figsize=(10, 5))
for variable, label, color in [
    ("time_hhi", "시간대 HHI", COLORS[0]),
    ("age_hhi", "연령대 HHI", COLORS[1]),
]:
    ax.plot(
        trend["qcode"].astype(str), trend[variable],
        marker="o", markersize=3, label=label, color=color,
    )
ax.tick_params(axis="x", rotation=45)
ax.set(xlabel="기준 분기", ylabel="행별 평균 HHI", title="매출 구조의 분기별 변화")
ax.legend(frameon=False)
style_axis(ax)

finish_figure(
    fig, "07_hhi_quarter_trend",
    "상권 구성 변화가 포함된 비균형 패널 평균이에요. "
    "동일 상권만의 변화와 동일하지 않을 수 있어요.",
)
save_table(trend, "07_hhi_quarter_trend.csv")


# 연령정보가 얼마나 포착되는지
values = analysis["age_coverage"].dropna()
fig, ax = plt.subplots(figsize=(8, 5))
ax.hist(values[values.between(0, 1.05)], bins=40, color=COLORS[0])
ax.set(
    xlabel="연령별 매출 합계 / 전체 매출",
    ylabel="관측 행 수",
    title="연령대 HHI를 읽기 전에 정보 포착률부터 확인해요",
)
style_axis(ax)

finish_figure(
    fig, "08_age_information_coverage",
    "0~1.05 범위를 표시해요. 미포착 부분의 고객 구성을 추정하거나 채워 넣지 않아요.",
)

scatter_with_line(
    analysis, "sales_cv4", "close_h1",
    "09_volatility_future_closure",
    "최근 4분기 매출 변동계수", "다음 분기 제공 폐업률 (%)",
    trim=True,
)

scatter_with_line(
    analysis, "overheat_yoy_pp", "close_h1",
    "10_overheat_future_closure",
    "점포 증가율 - 매출 증가율, 전년동기 (%p)",
    "다음 분기 제공 폐업률 (%)",
    trim=True,
)

record_status("기초 시각화", "완료", f"현재 그림 {len(FIGURES)}종")


# ------------------------------------------------------------
# 9. 패널 고정효과 분석
#
# 같은 상권×업종의 변하지 않는 특성과,
# 각 분기에 서울 전체가 함께 겪는 변화를 통제해요.
#
# 그래도 인과관계가 증명되는 것은 아니에요.
# 임대료 변화처럼 관측하지 못한 요인이 남을 수 있어요.
# ------------------------------------------------------------

panel_results = []
panel_fit_summary = []

if RUN_PANEL_MODEL:
    try:
        from linearmodels.panel import PanelOLS

        specifications = {
            "기본 구조": [
                "time_hhi", "age_hhi",
                "log_sales", "log_stores", "age_coverage",
            ],
            "구조 확장": [
                "time_hhi", "age_hhi",
                "sales_cv4", "overheat_yoy_pp",
                "time_js_change",
                "log_sales", "log_stores", "age_coverage",
            ],
            "시간길이 보정": [
                "time_duration_concentration", "age_hhi",
                "sales_cv4", "overheat_yoy_pp",
                "log_sales", "log_stores", "age_coverage",
            ],
        }

        for specification, variables in specifications.items():
            needed = [
                "entity", "t", "area_key", "close_h1",
            ] + variables

            d = analysis[needed].dropna().copy()

            # 한 번만 나온 상권×업종은 변화 분석에 도움이 적어요.
            n_per_entity = d.groupby("entity")["t"].transform("size")
            d = d[n_per_entity >= 3].copy()

            if len(d) < 500 or d["area_key"].nunique() < 30:
                record_status(
                    f"패널 모형: {specification}", "건너뜀",
                    "완전한 관측치 또는 상권 수가 부족해요.",
                )
                continue

            d = d.set_index(["entity", "t"]).sort_index()
            sd = d[variables].std(ddof=0)
            usable = sd[sd > 0].index.tolist()

            # 서로 다른 단위를 비교하려고 1표준편차 단위로 바꿔요.
            X = (d[usable] - d[usable].mean()) / sd[usable]

            cluster = pd.DataFrame(
                {"area_cluster": pd.factorize(d["area_key"])[0]},
                index=d.index,
            )

            fitted = PanelOLS(
                d["close_h1"],
                X,
                entity_effects=True,
                time_effects=True,
                drop_absorbed=True,
            ).fit(
                cov_type="clustered",
                clusters=cluster,
            )

            ci = fitted.conf_int()

            for variable in fitted.params.index:
                panel_results.append({
                    "specification": specification,
                    "variable": variable,
                    "beta_pp_per_1sd": fitted.params[variable],
                    "se": fitted.std_errors[variable],
                    "lower95": ci.loc[variable].iloc[0],
                    "upper95": ci.loc[variable].iloc[1],
                    "p_value": fitted.pvalues[variable],
                    "n": fitted.nobs,
                    "area_clusters": d["area_key"].nunique(),
                })

            panel_fit_summary.append({
                "specification": specification,
                "n": fitted.nobs,
                "entities": d.index.get_level_values(0).nunique(),
                "quarters": d.index.get_level_values(1).nunique(),
                "rsquared_within": fitted.rsquared_within,
                "note": "모형별 완전 관측 표본이 달라 R²를 단순 비교하지 않음",
            })

        coef = pd.DataFrame(panel_results)

        if len(coef):
            coef["q_value_BH_exploratory"] = multipletests(
                coef["p_value"], method="fdr_bh"
            )[1]

            save_table(coef, "panel_coefficients.csv")
            save_table(pd.DataFrame(panel_fit_summary), "panel_model_samples.csv")

            show = coef[
                (coef["specification"] == "구조 확장")
                & ~coef["variable"].isin(["log_sales", "log_stores", "age_coverage"])
            ].copy()

            if len(show):
                fig, ax = plt.subplots(figsize=(9, 5))
                positions = np.arange(len(show))
                center = show["beta_pp_per_1sd"].to_numpy()

                ax.errorbar(
                    center, positions,
                    xerr=np.vstack([
                        center - show["lower95"].to_numpy(),
                        show["upper95"].to_numpy() - center,
                    ]),
                    fmt="o", color=COLORS[0], capsize=4,
                )
                ax.axvline(0, color="#737D96", linestyle="--", linewidth=1)
                ax.set_yticks(positions, show["variable"])
                ax.set(
                    xlabel="변수 1표준편차 증가와 연결된 이후 폐업률 차이 (%p)",
                    title="상권×업종·분기 고정효과를 고려한 관계",
                )
                style_axis(ax)

                finish_figure(
                    fig, "11_panel_coefficients",
                    "상권별 군집 표준오차의 95% 구간. "
                    "관측자료의 조건부 관계이며 인과효과로 해석하지 않아요.",
                )

            record_status("패널 분석", "완료", f"계수 {len(coef)}개")
        else:
            record_status("패널 분석", "건너뜀", "분석 가능한 표본이 부족해요.")

    except Exception:
        message = traceback.format_exc()
        (OUT / "tables" / "panel_model_error.txt").write_text(
            message, encoding="utf-8"
        )
        record_status("패널 분석", "실패", "오류 내용을 별도 파일에 저장했어요.")


# ------------------------------------------------------------
# 10. 미래 예측에서 구조 변수가 정말 도움이 되는지
#
# 비교 모형:
# A. 지금의 폐업률이 그대로 이어진다고 보는 단순 모형
# B. 매출·점포 규모와 기존 폐업률을 보는 모형
# C. B에 매출 구조 변수를 추가한 모형
#
# 중요한 점:
# - 최신 매출 연도를 평가용으로 사용해요.
# - 학습할 때는 그 시점에 확인 가능한 과거 결과만 사용해요.
# - 하이퍼파라미터는 평가 결과를 보고 고르지 않아요.
# - 기본 예측은 두 분기 뒤예요.
#
# 분기 자료의 공개 지연을 고려한 보수적인 설계지만,
# 과거 시점에 실제 공개되었던 데이터 판본은 없으므로
# 완전한 실시간 백테스트라고 주장하지 않아요.
# ------------------------------------------------------------

prediction_frames = []
prediction_metrics = []
prediction_improvements = []

BASE_FEATURES = [
    "log_sales", "log_stores",
    "sales_growth_qoq", "sales_growth_yoy",
    "store_growth_qoq", "store_growth_yoy",
    "published_close",
    "year", "quarter_sin", "quarter_cos",
]

STRUCTURE_FEATURES = [
    "time_hhi", "age_hhi", "time_duration_concentration",
    "sales_cv4", "per_store_cv4", "day_hhi",
    "weekend_daily_ratio", "night_share",
    "time_js_change", "age_js_change",
    "age_coverage", "time_count_hhi", "amount_count_hhi_gap",
    "franchise_share_proxy", "area_industry_hhi",
]

CATEGORIES = ["industry", "area_type"]


def prediction_matrices(train, test, numeric):
    """業種の番号付けも学習用資料だけで決めます。"""
    # 숫자 부분은 빈칸을 그대로 둘 수 있는 모형을 사용해요.
    A = train[numeric].to_numpy(dtype=float)
    B = test[numeric].to_numpy(dtype=float)

    A[~np.isfinite(A)] = np.nan
    B[~np.isfinite(B)] = np.nan

    train_parts = [A]
    test_parts = [B]

    for c in CATEGORIES:
        categories = sorted(train[c].dropna().astype(str).unique())
        mapping = {value: i for i, value in enumerate(categories)}

        train_parts.append(
            train[c].astype(str).map(mapping).to_numpy(dtype=float)[:, None]
        )
        test_parts.append(
            test[c].astype(str).map(mapping).to_numpy(dtype=float)[:, None]
        )

    return (
        np.column_stack(train_parts),
        np.column_stack(test_parts),
        [False] * len(numeric) + [True] * len(CATEGORIES),
    )


if RUN_PREDICTION:
    try:
        target = f"close_h{PREDICTION_HORIZON}"
        pred_data = analysis[analysis[target].notna()].copy()

        test_year = int(panel["year"].max())

        all_areas = np.array(sorted(pred_data["area_key"].unique()))
        local_rng = np.random.default_rng(SEED)
        local_rng.shuffle(all_areas)

        holdout_areas = set(
            all_areas[:max(1, int(len(all_areas) * 0.2))]
        )

        experiments = ["時間外評価"]
        # 表示名を分かりやすい韓国語にします。
        experiments = ["미래 분기 평가"]

        if RUN_AREA_HOLDOUT:
            experiments.append("미학습 상권 + 미래 분기 평가")

        for experiment in experiments:
            for origin in sorted(
                pred_data.loc[pred_data["year"].eq(test_year), "t"].unique()
            ):
                # 목표 분기의 결과까지 origin 시점 이전에 있어야 학습해요.
                train = pred_data[
                    pred_data["t"] + PREDICTION_HORIZON <= origin
                ].copy()

                test = pred_data[pred_data["t"].eq(origin)].copy()

                if experiment == "미학습 상권 + 미래 분기 평가":
                    train = train[
                        ~train["area_key"].isin(holdout_areas)
                    ].copy()
                    test = test[
                        test["area_key"].isin(holdout_areas)
                    ].copy()

                if len(train) < 500 or len(test) < 30:
                    continue

                fold = test[
                    ["area_key", "area_name", "industry_name", "qcode", "t"]
                ].copy()

                fold["target_qcode"] = qcode_from_t(
                    fold["t"] + PREDICTION_HORIZON
                )
                fold["actual"] = test[target].to_numpy()
                fold["experiment"] = experiment

                fallback = float(train[target].median())

                fold["persistence"] = (
                    test["published_close"]
                    .fillna(fallback)
                    .clip(0, 100)
                    .to_numpy()
                )

                for name, numeric in [
                    ("scale", BASE_FEATURES),
                    ("structure", BASE_FEATURES + STRUCTURE_FEATURES),
                ]:
                    A, B, categorical_mask = prediction_matrices(
                        train, test, numeric
                    )

                    model = HistGradientBoostingRegressor(
                        loss="squared_error",
                        max_iter=120,
                        learning_rate=0.06,
                        max_leaf_nodes=15,
                        min_samples_leaf=50,
                        l2_regularization=10.0,
                        categorical_features=categorical_mask,
                        early_stopping=False,
                        random_state=SEED,
                    )

                    model.fit(A, train[target].to_numpy())
                    fold[name] = np.clip(model.predict(B), 0, 100)

                    del A, B, model
                    gc.collect()

                prediction_frames.append(fold)

        if prediction_frames:
            predictions = pd.concat(prediction_frames, ignore_index=True)
            save_table(predictions, "out_of_time_predictions.csv.gz")

            for experiment, z in predictions.groupby("experiment"):
                for model_name in ["persistence", "scale", "structure"]:
                    prediction_metrics.append({
                        "experiment": experiment,
                        "model": model_name,
                        "n": len(z),
                        "MAE_pp": mean_absolute_error(z["actual"], z[model_name]),
                        "RMSE_pp": np.sqrt(
                            mean_squared_error(z["actual"], z[model_name])
                        ),
                        "R2": r2_score(z["actual"], z[model_name]),
                    })

                # 두 모형을 같은 관측치에서 비교해요.
                z = z.copy()
                z["absolute_error_improvement"] = (
                    (z["actual"] - z["scale"]).abs()
                    - (z["actual"] - z["structure"]).abs()
                )

                grouped = z.groupby("area_key")[
                    "absolute_error_improvement"
                ].agg(["sum", "count"])

                G = len(grouped)
                weights = rng.multinomial(
                    G, np.full(G, 1 / G), size=BOOTSTRAPS
                )

                boots = (
                    weights @ grouped["sum"].to_numpy()
                ) / (
                    weights @ grouped["count"].to_numpy()
                )

                prediction_improvements.append({
                    "experiment": experiment,
                    "MAE_improvement_pp": z["absolute_error_improvement"].mean(),
                    "lower95": np.quantile(boots, 0.025),
                    "upper95": np.quantile(boots, 0.975),
                    "n": len(z),
                    "area_clusters": G,
                    "interpretation": "양수이면 구조 추가 모형의 MAE가 더 작음",
                })

            metrics = pd.DataFrame(prediction_metrics)
            improvements = pd.DataFrame(prediction_improvements)

            save_table(metrics, "prediction_metrics.csv")
            save_table(improvements, "prediction_improvement_cluster_bootstrap.csv")

            experiment_names = metrics["experiment"].unique()
            fig, axes = plt.subplots(
                1, len(experiment_names),
                figsize=(7 * len(experiment_names), 5),
                squeeze=False,
            )

            model_order = ["persistence", "scale", "structure"]
            model_labels = ["현재 폐업률 유지", "규모 중심", "구조 추가"]

            for ax, experiment in zip(axes.flat, experiment_names):
                z = (
                    metrics[metrics["experiment"].eq(experiment)]
                    .set_index("model")
                    .reindex(model_order)
                )

                ax.bar(
                    model_labels, z["MAE_pp"],
                    color=COLORS[:3], width=0.65,
                )
                ax.set(
                    ylabel="평균 절대오차 MAE (%p), 작을수록 좋음",
                    title=experiment,
                )
                ax.set_ylim(bottom=0)
                style_axis(ax)

            finish_figure(
                fig, "12_prediction_comparison",
                "두 분기 뒤 상권×업종의 제공 폐업률 예측. "
                "개별 가게의 폐업확률이 아니에요. 개선의 불확실성은 별도 표를 보세요.",
            )

            record_status("미래 예측 비교", "완료", f"평가 행 {len(predictions):,}개")
        else:
            record_status(
                "미래 예측 비교", "건너뜀",
                "미래 결과와 과거 학습자료가 충분한 평가 분기가 없어요.",
            )

    except Exception:
        message = traceback.format_exc()
        (OUT / "tables" / "prediction_error.txt").write_text(
            message, encoding="utf-8"
        )
        record_status("미래 예측 비교", "실패", "오류 내용을 별도 파일에 저장했어요.")


# ------------------------------------------------------------
# 11. 예비 창업자가 살펴볼 비교표
#
# '여기가 안전하다'고 단정하지 않아요.
# 같은 업종 안에서 무엇을 더 확인해야 하는지 보여줘요.
# ------------------------------------------------------------

latest_qcode = int(analysis["qcode"].max())
latest = analysis[analysis["qcode"].eq(latest_qcode)].copy()

for variable in ["time_hhi", "age_hhi", "sales_cv4", "overheat_yoy_pp"]:
    latest[f"{variable}_within_industry_percentile"] = (
        latest.groupby("industry")[variable].rank(pct=True)
    )

review_columns = [
    "qcode", "area_type_name", "area_name", "industry_name",
    "stores", "sales",
    "time_hhi", "age_hhi", "time_duration_concentration",
    "sales_cv4", "overheat_yoy_pp",
    "age_coverage", "time_peak_share", "night_share",
    "weekend_daily_ratio", "mean_ticket",
    "published_close",
] + [
    f"{v}_within_industry_percentile"
    for v in ["time_hhi", "age_hhi", "sales_cv4", "overheat_yoy_pp"]
]

save_table(
    latest[review_columns].sort_values(["industry_name", "area_name"]),
    "startup_review_latest_sales_quarter.csv",
)

# 이 표에는 현재 창업의 '최적 순위'를 붙이지 않아요.
# 특히 최신 매출 자료가 2024년이라면 2026년 현재 추천표가 아니에요.


# ------------------------------------------------------------
# 12. 변수 설명서와 연구 후보
# ------------------------------------------------------------

variable_dictionary = [
    ("time_hhi", "시간대 매출 집중도", "시간대 매출 비중 제곱의 합", "핵심"),
    ("age_hhi", "연령대 매출 집중도", "연령정보가 있는 매출 안에서 비중 제곱의 합", "핵심"),
    ("time_duration_concentration", "시간길이 보정 편중도", "sum(p²/(시간길이/24))-1", "추가"),
    ("sales_cv4", "최근 4분기 매출 변동성", "연속 4분기의 표본표준편차/평균", "핵심"),
    ("overheat_qoq_pp", "전분기 과열 신호", "점포 증가율-매출 증가율, %p", "핵심"),
    ("overheat_yoy_pp", "전년동기 과열 신호", "전년동기 점포 증가율-매출 증가율, %p", "핵심"),
    ("time_entropy", "시간대 매출 다양성", "정규화 Shannon entropy", "추가"),
    ("age_entropy", "연령대 매출 다양성", "정규화 Shannon entropy", "추가"),
    ("time_effective_bins", "유효 시간 구간 수", "1/시간대 HHI", "추가"),
    ("age_effective_groups", "유효 연령 집단 수", "1/연령대 HHI", "추가"),
    ("time_peak_share", "최대 시간대 의존도", "가장 큰 시간대 매출 비중", "추가"),
    ("night_share", "야간 매출 비중", "00~06 및 21~24 매출 비중 합", "추가"),
    ("day_hhi", "요일 집중도", "7개 요일별 매출 비중 HHI", "추가"),
    ("weekend_daily_ratio", "주말 일평균 매출 강도", "주말 일평균/평일 일평균", "추가"),
    ("time_js_change", "시간 구조 변화", "전분기와 현재 시간 비중의 JS divergence", "추가"),
    ("age_js_change", "연령 구조 변화", "전분기와 현재 연령 비중의 JS divergence", "추가"),
    ("time_count_hhi", "거래건수의 시간대 집중도", "시간대 거래건수 비중 HHI", "추가"),
    ("amount_count_hhi_gap", "금액과 건수의 집중도 차이", "금액 HHI-건수 HHI", "추가"),
    ("age_coverage", "연령정보 포착률", "연령별 매출 합계/전체 매출", "품질"),
    ("mean_ticket", "거래당 평균 금액", "매출액/거래건수", "추가"),
    ("franchise_share_proxy", "프랜차이즈 비중 참고값", "프랜차이즈/유사업종점포수", "분모 확인 필요"),
    ("area_industry_hhi", "상권 업종 구성 집중도", "관측된 업종별 점포 비중 HHI", "추가"),
    ("close_h1", "다음 분기 폐업률", "정확히 다음 분기의 원자료 제공 폐업률", "결과"),
    ("close_h2", "두 분기 뒤 폐업률", "정확히 두 분기 뒤의 원자료 제공 폐업률", "결과"),
    ("close_h4", "네 분기 뒤 폐업률", "정확히 네 분기 뒤의 원자료 제공 폐업률", "결과"),
]

save_table(
    pd.DataFrame(
        variable_dictionary,
        columns=["variable", "korean_name", "definition", "role"],
    ),
    "variable_dictionary.csv",
)


# ------------------------------------------------------------
# 13. 읽는 방법을 결과물에 함께 넣어요.
# ------------------------------------------------------------

finding_lines = []

for row in prediction_improvements:
    if row["lower95"] > 0:
        conclusion = (
            "이 평가에서는 구조 추가 모형의 MAE 개선 구간이 0보다 컸어요. "
            "다른 도시·시기에서도 유지되는지는 별도로 확인해야 해요."
        )
    elif row["upper95"] < 0:
        conclusion = (
            "이 평가에서는 구조 추가 모형의 오차가 더 컸어요. "
            "구조 변수가 도움이 된다고 주장하면 안 돼요."
        )
    else:
        conclusion = (
            "개선 구간이 0을 포함해요. "
            "구조 추가의 예측 이득이 분명하다고 말하기 어려워요."
        )

    finding_lines.append(
        f"- {row['experiment']}: MAE 개선 "
        f"{row['MAE_improvement_pp']:.4f}%p "
        f"(95% 구간 {row['lower95']:.4f}~{row['upper95']:.4f}). "
        + conclusion
    )

if not finding_lines:
    finding_lines = [
        "- 예측 개선 결과가 생성되지 않았어요. execution_status.csv를 확인해 주세요."
    ]

report = f"""
# 서울 상권 매출 구조 분석: 결과 읽는 방법

## 1. 이번 실행
- 매출 행: {len(sales):,}
- 점포 행: {len(stores):,}
- 매출 기간: {int(sales.qcode.min())}~{int(sales.qcode.max())}
- 점포 기간: {int(stores.qcode.min())}~{int(stores.qcode.max())}
- 품질 조건 적용 후 분석 행: {len(analysis):,}
- 생성된 그림: {len(FIGURES)}
- PNG 저장 해상도: {DPI}dpi
- 표본의 최소 점포 수 기준: {MIN_STORES}

## 2. 우선 볼 파일
1. tables/execution_status.csv: 실제로 어느 단계가 끝났는지
2. tables/input_manifest.csv: 어떤 파일을 읽었는지
3. tables/quality_log.csv: 데이터 문제와 처리 내용
4. tables/closure_denominator_audit.csv: 폐업률 분모 점검
5. figures/02_time_hhi_future_closure.png: HHI와 다음 분기 폐업률
6. figures/03_hhi_bins_future_closure.png: HHI 구간별 평균
7. tables/panel_coefficients.csv: 고정효과 분석, 생성된 경우
8. tables/prediction_metrics.csv: 미래 예측 비교, 생성된 경우
9. tables/prediction_improvement_cluster_bootstrap.csv: 개선 불확실성
10. tables/startup_review_latest_sales_quarter.csv: 업종 안의 비교표

## 3. 자동으로 확인한 예측 결과
{chr(10).join(finding_lines)}

## 4. 연구 질문
매출 규모를 이미 알고 있어도, 시간·연령별 매출 구조가
상권×업종의 이후 폐업률에 추가적인 정보를 주는가?

## 5. 중요한 해석 제한
- 분석 단위는 상권×업종×분기이며, 개별 가게가 아니에요.
- 제공 폐업률의 행별 평균은 서울 전체 점포의 가중 폐업률과 달라요.
- 매출은 추정치이며 실제 이익이 아니에요.
- 원본 열 이름의 '당월'을 근거로 월 자료로 바꾸거나 3을 곱하지 않았어요.
- 연령 HHI는 연령정보가 관측된 매출의 구성에 대한 값이에요.
- 시간 구간 길이가 달라 원래 HHI와 시간길이 보정 편중도를 함께 제공해요.
- 폐업률의 분모를 자동 교체하지 않았어요.
- 없는 행을 0이나 폐업으로 채우지 않았어요.
- 과열 신호는 점포당 매출 변화와 수학적으로 밀접한 값이에요.
- HHI×HHI는 상호작용항이지 시간×연령 결합분포의 HHI가 아니에요.
- 개별 점포 생존기간이 없으므로 생존분석을 수행하지 않았어요.
- 고정효과를 넣어도 인과효과가 증명되지는 않아요.
- 패널 분석의 다중검정 보정은 생성된 계수 전체에 대한 탐색적 BH-FDR이에요.
- 모형별 완전 관측 표본이 달라 R²를 직접 비교하지 않아요.
- 예측 평가는 과거 자료 공개 지연을 고려한 근사 설계예요.
- 과거 공개 판본이 없으므로 자료 수정에 따른 실시간 백테스트 한계가 있어요.
- 상권 홀드아웃은 인접 상권까지 거리로 차단한 공간 검증이 아니에요.
- 코로나 이전 자료가 없어 팬데믹의 인과효과를 식별하지 않았어요.
- 임대료·인건비·원가가 없어 창업 수익성이나 최적 입지를 단정할 수 없어요.
- 최신 매출 연도 이후의 현재 상황을 추천하는 자료가 아니에요.

## 6. 후속 연구 우선순위
1. 시간대 HHI의 비선형 효과: 집중이 항상 나쁜지, 적정 수준이 있는지
2. 업종별 차이: 음식점과 소매업이 같은 패턴인지
3. 시간 집중도×연령 집중도 상호작용
4. 시간 집중도×전년동기 과열 신호 상호작용
5. 집중도 수준보다 구조의 급변이 더 중요한지
6. 매출액 HHI와 거래건수 HHI가 다른 정보를 주는지
7. 최소 점포 수 3·5·10개 기준의 민감도
8. 연령정보 포착률 0.6·0.8·0.9 기준의 민감도
9. 2021년 포함 여부, 상권 유형별 분리, 균형 패널 민감도
10. 미래 1·2·4분기 결과 비교
11. 업종×분기 고정효과, 비선형 모형, 미관측 교란에 대한 검토
12. 임대료·유동인구·직장인구·공간 경계 추가
13. 다른 도시 또는 새로운 연도의 사전 등록된 외부 검증

## 7. 참고 자료
- 서울시 상권분석서비스 제공정보:
  https://golmok.seoul.go.kr/main.do
- Economic outcomes predicted by diversity in cities:
  https://link.springer.com/article/10.1140/epjds/s13688-020-00234-x
- Behaviour-based dependency networks between places shape urban economic resilience:
  https://www.nature.com/articles/s41562-024-02072-7

위 선행연구를 바탕으로 연구 방향을 제안한 것이며,
체계적 문헌고찰이나 신규성 검증을 완료한 것은 아니에요.
"""

(OUT / "README_결과읽는방법.md").write_text(report.strip(), encoding="utf-8")

settings = {
    "seed": SEED,
    "dpi": DPI,
    "minimum_stores": MIN_STORES,
    "bootstraps": BOOTSTRAPS,
    "prediction_horizon": PREDICTION_HORIZON,
    "focus_industry": FOCUS_INDUSTRY,
    "figures": FIGURES,
    "primary_outcome": "원자료 제공 폐업률",
    "cluster_unit": "상권 구분 코드 × 상권 코드",
}

(OUT / "run_settings.json").write_text(
    json.dumps(settings, ensure_ascii=False, indent=2),
    encoding="utf-8",
)


# ------------------------------------------------------------
# 14. 실행 코드와 코랩 노트북도 같이 보관해요.
#
# 만들어지는 노트북에는:
# 쉬운 설명 텍스트 셀 + 설치 셀 + 전체 실행 셀이 들어가요.
# ------------------------------------------------------------

if MAIN_SOURCE and "def read_one_csv" in MAIN_SOURCE:
    (OUT / "code" / "seoul_all_in_one.py").write_text(
        MAIN_SOURCE, encoding="utf-8"
    )

    install_source = (
        "%pip -q install pandas numpy scipy matplotlib koreanize-matplotlib "
        "statsmodels linearmodels scikit-learn pillow"
    )

    def markdown_cell(text):
        return {"cell_type": "markdown", "metadata": {}, "source": text}

    def code_cell(text):
        return {
            "cell_type": "code",
            "metadata": {},
            "execution_count": None,
            "outputs": [],
            "source": text,
        }

    notebook = {
        "nbformat": 4,
        "nbformat_minor": 4,
        "metadata": {
            "colab": {"name": "서울상권_매출구조_올인원.ipynb"},
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            },
        },
        "cells": [
            markdown_cell(
                "# 서울 상권, 매출의 크기보다 모양을 살펴봐요\n\n"
                "이 노트북은 ZIP을 읽고, 필요한 변수를 만든 뒤, "
                "그림과 분석표를 ZIP으로 묶어요.\n\n"
                "★ 먼저 원본 ZIP을 준비해요.\n\n"
                "【함정】비어 있는 숫자는 0이 아니에요. "
                "상권의 폐업률은 내 가게의 폐업확률도 아니에요."
            ),
            code_cell(install_source),
            markdown_cell(
                "## 전체 분석을 시작해요\n\n"
                "아래 셀을 실행하면 파일 선택창이 나와요. "
                "원본 ZIP들을 한꺼번에 골라 주세요.\n\n"
                "코드에는 0~14번 안내판이 있어요. "
                "처음에는 설정을 바꾸지 않아도 괜찮아요.\n\n"
                "그림은 650dpi PNG와 PDF로 저장돼요. "
                "실패하거나 건너뛴 단계는 실행 상태 표에 남아요."
            ),
            code_cell(MAIN_SOURCE),
            markdown_cell(
                "## 결과를 읽는 순서\n\n"
                "1. 실행 상태를 확인해요.\n"
                "2. 데이터 품질과 폐업률 분모를 확인해요.\n"
                "3. 산점도와 구간별 그림을 봐요.\n"
                "4. 고정효과 분석과 미래 예측 결과를 구분해서 읽어요.\n"
                "5. 구조 변수가 도움이 안 되는 결과도 그대로 받아들여요.\n\n"
                "【함정】유의한 관계를 찾았다고 인과관계가 증명되지는 않아요."
            ),
        ],
    }

    (OUT / "code" / "서울상권_매출구조_올인원.ipynb").write_text(
        json.dumps(notebook, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    record_status("코드·노트북 보관", "완료")
else:
    record_status(
        "코드·노트북 보관", "건너뜀",
        "실행 셀의 원문을 가져오지 못했어요. 코랩 메뉴에서 노트북을 저장해 주세요.",
    )


# ------------------------------------------------------------
# 15. ZIP으로 묶고 다운로드
# ------------------------------------------------------------

save_table(pd.DataFrame(STATUS), "execution_status.csv")

archive = ROOT / f"{OUT.name}.zip"

with zipfile.ZipFile(
    archive, "w",
    compression=zipfile.ZIP_DEFLATED,
    compresslevel=6,
) as z:
    for path in OUT.rglob("*"):
        if path.is_file():
            z.write(path, arcname=path.relative_to(OUT))

# ZIP이 손상되지 않았는지도 확인해요.
with zipfile.ZipFile(archive) as z:
    bad_member = z.testzip()

if bad_member is not None:
    raise RuntimeError(f"ZIP 검사에서 문제가 발견됐어요: {bad_member}")

print("\n==============================")
print("결과 ZIP을 만들었어요.")
print("파일:", archive.name)
print("그림 수:", len(FIGURES))
print("해상도:", DPI, "dpi")
print("==============================\n")
print(pd.DataFrame(STATUS).to_string(index=False))
print("\n실패·건너뜀 항목이 있다면 해당 분석은 완료된 것이 아니에요.")

try:
    from google.colab import files
    files.download(str(archive))
except ImportError:
    print("결과 ZIP 위치:", archive)
