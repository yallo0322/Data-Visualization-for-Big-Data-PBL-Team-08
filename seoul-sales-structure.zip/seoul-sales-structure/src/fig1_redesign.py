# ============================================================
# 그림 1(결과 폴더의 03번 그림) 논문용 디자인 + 결과 ZIP 다시 묶기
#
# 올인원 코드 바로 뒤에 돌려도 되고, 런타임이 초기화된 뒤에 따로 돌려도 돼요.
# (메모리에 analysis가 없으면 결과 폴더/ZIP의 03번 표를 읽어서 그려요.)
#   1) 그림 3을 '서울 평균 대비' 방식으로 다시 그리고
#   2) figures 폴더의 03번 그림(PNG·PDF)을 새 그림으로 바꾸고
#   3) 결과 ZIP을 다시 만들어 내려받아요.
# 숫자는 원래 그림과 똑같고, 보여주는 방식만 바꿨어요.
# ============================================================

# 한글 글꼴 준비 (런타임이 새로 켜졌을 때도 한글이 깨지지 않게)
try:
    import koreanize_matplotlib
except ImportError:
    import subprocess, sys as _sys
    subprocess.run([_sys.executable, "-m", "pip", "install", "-q", "koreanize-matplotlib"], check=True)
    import koreanize_matplotlib

import zipfile
import numpy as np
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42   # PDF 안 글자를 '글자'로 저장 (확대해도 선명, 수정 가능)
matplotlib.rcParams['svg.fonttype'] = 'none'
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.colors import TwoSlopeNorm, LinearSegmentedColormap
from PIL import Image

# ------------------------------------------------------------
# 0. 결과 폴더 찾기 (런타임이 초기화돼도 작동하게)
#    1순위: 지금 메모리에 있는 OUT
#    2순위: 코랩(/content)에 남아 있는 결과 폴더 중 가장 최근 것
#    3순위: 결과 ZIP(seoul_structure_results_*.zip)을 찾아 압축 풀기
#    4순위: 아무것도 없으면 결과 ZIP을 직접 올려 달라고 업로드 창을 띄워요
# ------------------------------------------------------------
import zipfile
from pathlib import Path


def find_results_folder(need_file):
    if "OUT" in globals() and (Path(OUT) / "tables" / need_file).exists():
        return Path(OUT)

    base = Path("/content") if Path("/content").exists() else Path.cwd()

    folders = sorted(
        [p for p in base.glob("seoul_structure_results_*")
         if p.is_dir() and (p / "tables" / need_file).exists()],
        key=lambda p: p.stat().st_mtime,
    )
    if folders:
        return folders[-1]

    zips = sorted(base.glob("seoul_structure_results_*.zip"), key=lambda p: p.stat().st_mtime)
    if not zips:
        try:
            from google.colab import files
            print("결과 ZIP(seoul_structure_results_...zip)을 올려 주세요.")
            up = files.upload()
            zips = [base / name for name in up if name.endswith(".zip")]
        except ImportError:
            pass
    for z in reversed(zips):
        target = base / z.stem.replace("_v2", "")
        target.mkdir(exist_ok=True)
        with zipfile.ZipFile(z) as zf:
            zf.extractall(target)
        hits = list(target.rglob(f"tables/{need_file}"))
        if hits:
            return hits[0].parent.parent

    raise RuntimeError(
        f"결과 폴더를 찾지 못했어요. 올인원 코드를 실행하거나, 결과 ZIP을 올려 주세요. (필요한 파일: {need_file})"
    )


FIG_DPI = max(int(globals().get("DPI", 650)), 600)
N_BOOT = int(globals().get("BOOTSTRAPS", 400))
BG = globals().get("SURFACE", "#FDFDFF")
rng03 = np.random.default_rng(int(globals().get("SEED", 42)))

# ------------------------------------------------------------
# 1. 구간별 폐업률과 신뢰구간 준비
#    메모리에 analysis 표가 있으면 원래 방법 그대로 다시 계산하고,
#    없으면(런타임 초기화) 결과 폴더의 03번 표를 그대로 읽어요. 숫자는 같아요.
# ------------------------------------------------------------
if "analysis" in globals() and isinstance(analysis, pd.DataFrame) and "time_hhi" in analysis:
    if "OUT" not in globals():
        raise RuntimeError("analysis는 있는데 OUT 폴더가 없어요. 올인원 코드를 끝까지 실행해 주세요.")
    OUT = Path(OUT)
    bins03 = analysis[["time_hhi", "close_h1", "area_key"]].dropna().copy()
    bins03["bin"] = pd.qcut(bins03["time_hhi"], 5, labels=False, duplicates="drop")
    bins03 = bins03.dropna(subset=["bin"])
    bins03["bin"] = bins03["bin"].astype(int)
    summary03 = bins03.groupby("bin").agg(
        mean_closure=("close_h1", "mean"),
        observations=("close_h1", "size"),
        hhi_min=("time_hhi", "min"),
        hhi_max=("time_hhi", "max"),
    )
    # 한 상권의 모든 업종·분기를 한 묶음으로 다시 뽑아요(상권 단위 부트스트랩).
    sums03 = bins03.pivot_table(index="area_key", columns="bin",
                                values="close_h1", aggfunc="sum", fill_value=0)
    cnts03 = bins03.pivot_table(index="area_key", columns="bin",
                                values="close_h1", aggfunc="count", fill_value=0)
    sums03 = sums03.reindex(columns=summary03.index, fill_value=0)
    cnts03 = cnts03.reindex(index=sums03.index, columns=sums03.columns, fill_value=0)
    G03 = len(sums03)
    w03 = rng03.multinomial(G03, np.full(G03, 1 / G03), size=N_BOOT)
    with np.errstate(divide="ignore", invalid="ignore"):
        boot03 = (w03 @ sums03.to_numpy()) / (w03 @ cnts03.to_numpy())
    summary03["lower95"] = np.nanquantile(boot03, 0.025, axis=0)
    summary03["upper95"] = np.nanquantile(boot03, 0.975, axis=0)
    overall = float(bins03["close_h1"].mean())
else:
    OUT = find_results_folder("03_hhi_bins_table.csv")
    summary03 = pd.read_csv(OUT / "tables" / "03_hhi_bins_table.csv").set_index("bin")
    overall = float(np.average(summary03["mean_closure"], weights=summary03["observations"]))

print("사용할 결과 폴더:", OUT)

# ------------------------------------------------------------
# 2. 그림 그리기
#    빨강(위) = 서울 평균보다 폐업이 많은 구간
#    파랑(아래) = 서울 평균보다 폐업이 적은 구간
# ------------------------------------------------------------
BLUE, RED, GREY, DARK = "#1D4ED8", "#DC2626", "#6B7280", "#111827"
WHITE_EDGE = [pe.withStroke(linewidth=4, foreground="white")]
FS_TITLE, FS_SUB, FS_LABEL, FS_TICK, FS_VALUE, FS_NOTE = 20, 14, 15, 14, 16, 11

x = np.arange(len(summary03))
y = summary03["mean_closure"].to_numpy()
lo = summary03["lower95"].to_numpy() - overall
hi = summary03["upper95"].to_numpy() - overall
dev = y - overall
rel = dev / overall * 100

span = max(np.abs(np.r_[lo, hi]).max(), 1e-9)
norm = TwoSlopeNorm(vmin=-span, vcenter=0, vmax=span)
cmap = LinearSegmentedColormap.from_list("risk", [BLUE, "#D1D5DB", RED])
names = (["매우 분산", "분산", "중간", "집중", "매우 집중"]
         if len(x) == 5 else [f"{i + 1}구간" for i in x])

fig, ax = plt.subplots(figsize=(12, 7.6), facecolor=BG)
ax.set_facecolor(BG)

# 위/아래 배경색: 위험(빨강) / 안전(파랑)
ax.axhspan(0, span * 2.0, color=RED, alpha=0.045, zorder=0)
ax.axhspan(-span * 2.0, 0, color=BLUE, alpha=0.045, zorder=0)

# 가장 안전한 두 구간(붙어 있을 때) = 적정 집중 구간
safe = sorted(np.argsort(dev)[:2])
if safe[1] - safe[0] == 1:
    ax.axvspan(safe[0] - 0.42, safe[1] + 0.42, color=BLUE, alpha=0.10, zorder=0.5)
    ax.text((safe[0] + safe[1]) / 2, span * 1.82, "적정 집중 구간 (폐업 최저)",
            ha="center", va="center", fontsize=FS_LABEL, fontweight="bold",
            color=BLUE, path_effects=WHITE_EDGE)

# 서울 평균 기준선
ax.axhline(0, color=DARK, lw=1.8, zorder=2)

# U자 추세선 (구간 평균에 맞춘 2차 곡선, 참고용)
coef = np.polyfit(x, dev, 2, w=summary03["observations"].to_numpy())
xs = np.linspace(x.min() - 0.15, x.max() + 0.15, 200)
ax.plot(xs, np.polyval(coef, xs), ls=(0, (5, 4)), lw=2.2, color=GREY, zorder=1)

# 신뢰구간(옅은 굵은 막대) + 기준선에서 점까지 막대 + 큰 점
for xi, l, h, d in zip(x, lo, hi, dev):
    c = cmap(norm(d))
    ax.plot([xi, xi], [l, h], lw=20, solid_capstyle="round", color=c, alpha=0.25, zorder=3)
    ax.plot([xi, xi], [0, d], lw=3.2, color=c, zorder=4)
ax.scatter(x, dev, s=650, c=[cmap(norm(d)) for d in dev],
           edgecolor="white", linewidth=2.8, zorder=5)

# 값 라벨: 폐업률 + 평균 대비 %
for xi, d, v, r, l, h in zip(x, dev, y, rel, lo, hi):
    up = d >= 0
    ax.annotate(f"{v:.2f}%\n평균 대비 {r:+.1f}%",
                xy=(xi, h if up else l), xytext=(0, 14 if up else -14),
                textcoords="offset points", ha="center",
                va="bottom" if up else "top", fontsize=FS_VALUE,
                fontweight="bold", color=RED if up else BLUE,
                linespacing=1.25, path_effects=WHITE_EDGE)

# 오른쪽 여백 설명
ax.annotate("▲ 평균보다\n   폐업 많음", xy=(1.015, 0.80), xycoords="axes fraction",
            ha="left", va="center", fontsize=FS_LABEL, fontweight="bold", color=RED)
ax.annotate(f"서울 평균\n{overall:.2f}%", xy=(1.015, 0.50), xycoords="axes fraction",
            ha="left", va="center", fontsize=FS_TICK, fontweight="bold", color=DARK)
ax.annotate("▼ 평균보다\n   폐업 적음", xy=(1.015, 0.20), xycoords="axes fraction",
            ha="left", va="center", fontsize=FS_LABEL, fontweight="bold", color=BLUE)

# 축과 제목
ax.set_xticks(x, [f"{n}\n({r.hhi_min:.2f}~{r.hhi_max:.2f})"
                  for n, r in zip(names, summary03.itertuples())])
ax.tick_params(axis="x", labelsize=FS_TICK, length=0, pad=10, colors=DARK)
ax.tick_params(axis="y", labelsize=FS_TICK - 1, colors=DARK)
ax.set_xlim(-0.55, len(x) - 1 + 0.55)
ax.set_ylim(-span * 2.0, span * 2.0)
ax.set_xlabel("시간대 매출 집중도(HHI) 구간   →  오른쪽일수록 한 시간대에 매출이 몰림",
              fontsize=FS_LABEL, labelpad=12, color=DARK)
ax.set_ylabel("서울 평균 대비 다음 분기 폐업률 (%p)",
              fontsize=FS_LABEL, labelpad=10, color=DARK)
ax.spines[["top", "right"]].set_visible(False)
ax.grid(False)

fig.suptitle("매출이 '적당히' 몰린 상권의 폐업률이 가장 낮다",
             x=0.06, ha="left", fontsize=FS_TITLE, fontweight="bold", y=0.985, color=DARK)
ax.set_title("시간대 매출 집중도 5개 구간별 다음 분기 폐업률 (서울 상권×업종×분기)",
             loc="left", fontsize=FS_SUB, color=GREY, pad=12)

n_text = (f"각 구간 n={int(summary03['observations'].iloc[0]):,}"
          if summary03["observations"].nunique() == 1 else "구간별 n은 표 참고")
fig.text(0.02, 0.015,
         f"점: 구간 평균 | 옅은 막대: 상권 단위 부트스트랩 95% 신뢰구간 | "
         f"점선: U자 추세선 | {n_text}. 업종을 통제하지 않은 상권×업종×분기 평균이에요.",
         fontsize=FS_NOTE, color=GREY, va="bottom")

# 여백은 여기서 직접 정해요 (tight_layout을 쓰지 않아 글자가 겹치지 않아요).
fig.subplots_adjust(left=0.09, right=0.84, top=0.86, bottom=0.21)

# ------------------------------------------------------------
# 3. 저장: 기존 03번 그림을 새 그림으로 바꿔요.
# ------------------------------------------------------------
png03 = OUT / "figures" / "03_hhi_bins_future_closure.png"
pdf03 = OUT / "figures" / "03_hhi_bins_future_closure.pdf"
fig.savefig(png03, dpi=FIG_DPI, bbox_inches="tight", pad_inches=0.3, facecolor=BG)
fig.savefig(pdf03, dpi=FIG_DPI, bbox_inches="tight", pad_inches=0.3, facecolor=BG)
fig.savefig(pdf03.with_suffix('.svg'), dpi=FIG_DPI, bbox_inches="tight", pad_inches=0.3, facecolor=BG)
plt.show()   # 코랩 화면에도 바로 보여줘요.
plt.close(fig)

with Image.open(png03) as im:
    print("그림 3 저장 완료:", png03.name, "| 해상도:", im.info.get("dpi"), "| 크기:", im.size)

summary03.reset_index().to_csv(
    OUT / "tables" / "03_hhi_bins_table.csv", index=False, encoding="utf-8-sig")

# ------------------------------------------------------------
# 4. 결과 ZIP 다시 만들기 (새 그림 3이 들어간 버전)
# ------------------------------------------------------------
archive_v2 = OUT.parent / f"{OUT.name}_v2.zip"
with zipfile.ZipFile(archive_v2, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in OUT.rglob("*"):
        if path.is_file():
            z.write(path, arcname=path.relative_to(OUT))

with zipfile.ZipFile(archive_v2) as z:
    if z.testzip() is not None:
        raise RuntimeError("ZIP 검사에서 문제가 발견됐어요.")

print("새 결과 ZIP:", archive_v2.name)

try:
    from google.colab import files
    files.download(str(archive_v2))
except ImportError:
    print("결과 ZIP 위치:", archive_v2)
