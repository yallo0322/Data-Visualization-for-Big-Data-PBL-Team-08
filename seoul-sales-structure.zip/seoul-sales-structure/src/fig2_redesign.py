# ============================================================
# 그림 2(결과 폴더의 11번 그림) 논문용 디자인: 고정효과 계수 그림
#
# 올인원 코드 바로 뒤에 돌려도 되고, 런타임이 초기화된 뒤에 따로 돌려도 돼요.
# (메모리에 결과가 없으면 /content의 결과 폴더나 결과 ZIP을 알아서 찾아요.)
#
# 하는 일
#   1) 고정효과 분석 결과표(panel_coefficients.csv)를 읽어요.
#   2) "엄격히 따져도 남는 건 고객층 집중도 하나"가 한눈에 보이게 다시 그려요.
#      - 유의한 변수는 빨강, 효과 없는 변수는 회색
#      - 오른쪽에 효과 크기 · 95% 구간 · p값을 표처럼 정리
#      - 같은 변수를 다른 모형으로 추정한 값도 작은 표시로 함께 보여줘요(결과가 흔들리지 않는지)
#   3) figures 폴더의 11번 그림을 바꾸고, 결과 ZIP을 다시 만들어 내려받아요.
# 숫자는 원래 분석 결과 그대로예요. 보여주는 방식만 바꿨어요.
# ============================================================

# 한글 글꼴 준비 (런타임이 새로 켜졌을 때도 한글이 깨지지 않게)
try:
    import koreanize_matplotlib
except ImportError:
    import subprocess, sys as _sys
    subprocess.run([_sys.executable, "-m", "pip", "install", "-q", "koreanize-matplotlib"], check=True)
    import koreanize_matplotlib

import zipfile
import numpy as np
import matplotlib
matplotlib.rcParams['pdf.fonttype'] = 42   # PDF 안 글자를 '글자'로 저장 (확대해도 선명, 수정 가능)
matplotlib.rcParams['svg.fonttype'] = 'none'
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib import gridspec
from matplotlib.lines import Line2D
from PIL import Image

# ------------------------------------------------------------
# 0. 결과 폴더 찾기 (런타임이 초기화돼도 작동하게)
#    1순위: 지금 메모리에 있는 OUT
#    2순위: 코랩(/content)에 남아 있는 결과 폴더 중 가장 최근 것
#    3순위: 결과 ZIP(seoul_structure_results_*.zip)을 찾아 압축 풀기
#    4순위: 아무것도 없으면 결과 ZIP을 직접 올려 달라고 업로드 창을 띄워요
# ------------------------------------------------------------
import zipfile
from pathlib import Path


def find_results_folder(need_file):
    if "OUT" in globals() and (Path(OUT) / "tables" / need_file).exists():
        return Path(OUT)

    base = Path("/content") if Path("/content").exists() else Path.cwd()

    folders = sorted(
        [p for p in base.glob("seoul_structure_results_*")
         if p.is_dir() and (p / "tables" / need_file).exists()],
        key=lambda p: p.stat().st_mtime,
    )
    if folders:
        return folders[-1]

    zips = sorted(base.glob("seoul_structure_results_*.zip"), key=lambda p: p.stat().st_mtime)
    if not zips:
        try:
            from google.colab import files
            print("결과 ZIP(seoul_structure_results_...zip)을 올려 주세요.")
            up = files.upload()
            zips = [base / name for name in up if name.endswith(".zip")]
        except ImportError:
            pass
    for z in reversed(zips):
        target = base / z.stem.replace("_v2", "")
        target.mkdir(exist_ok=True)
        with zipfile.ZipFile(z) as zf:
            zf.extractall(target)
        hits = list(target.rglob(f"tables/{need_file}"))
        if hits:
            return hits[0].parent.parent

    raise RuntimeError(
        f"결과 폴더를 찾지 못했어요. 올인원 코드를 실행하거나, 결과 ZIP을 올려 주세요. (필요한 파일: {need_file})"
    )


OUT = find_results_folder("panel_coefficients.csv")
print("사용할 결과 폴더:", OUT)
coef11 = pd.read_csv(OUT / "tables" / "panel_coefficients.csv")

FIG_DPI = max(int(globals().get("DPI", 650)), 600)
BG = globals().get("SURFACE", "#FDFDFF")

MAIN_SPEC = "구조 확장"            # 그림에 크게 보여줄 모형 (원래 그림 11과 같아요)
OTHER_SPECS = ["기본 구조", "시간길이 보정"]   # 작은 표시로 함께 보여줄 모형

# 변수 이름을 사람이 읽는 말로 바꿔요. (위: 큰 이름 / 아래: 작은 설명)
NAMES = {
    "age_hhi":         ("고객층 집중도", "연령대별 매출 HHI"),
    "time_hhi":        ("시간대 집중도", "시간대별 매출 HHI"),
    "sales_cv4":       ("매출 변동성", "최근 4분기 변동계수"),
    "overheat_yoy_pp": ("과열 신호", "점포 증가율에서 매출 증가율을 뺀 값"),
    "time_js_change":  ("시간 구조 변화", "전 분기 대비 시간대 구성 변화"),
}

main = coef11[(coef11["specification"] == MAIN_SPEC) & coef11["variable"].isin(NAMES)].copy()
if main.empty:
    raise RuntimeError(f"'{MAIN_SPEC}' 모형의 결과가 표에 없어요.")

# 효과가 큰 순서로 위에서부터 놓아요. (유의한 변수가 맨 위)
main = main.sort_values("beta_pp_per_1sd", ascending=True).reset_index(drop=True)
main["sig"] = (main["lower95"] > 0) | (main["upper95"] < 0)

n_obs = int(main["n"].iloc[0]) if "n" in main else None
n_area = int(main["area_clusters"].iloc[0]) if "area_clusters" in main else None

# ------------------------------------------------------------
# 1. 색과 글씨 (네이처 스타일: 흰 바탕, 강조색 하나, 굵은 대비, 큰 글씨)
# ------------------------------------------------------------
ACCENT = "#B2182B"        # 유의한 결과 (짙은 빨강)
ACCENT_BAND = "#FBEFF0"   # 유의한 줄을 따라 읽기 쉽게 옅은 띠
INK2 = "#1F2937"          # 기본 글자색 (거의 검정, 대비 높게)
MUTED = "#4B5563"         # 효과 없는 변수 (회색이지만 충분히 진하게)
RULE = "#9CA3AF"          # 가는 선
BG = "#FFFFFF"
FS_TITLE, FS_SUB, FS_NAME, FS_DESC, FS_TICK, FS_TABLE, FS_NOTE, FS_PANEL = 20, 14, 17, 13, 14, 16, 12, 20

plt.rcParams["axes.linewidth"] = 1.0


def p_text(p):
    if p < 0.001:
        return "0.001 미만"
    return f"{p:.3f}" if p < 0.01 else f"{p:.2f}"


# ------------------------------------------------------------
# 2. 그림 틀: 왼쪽 a = 계수 그림, 오른쪽 b = 숫자 표
# ------------------------------------------------------------
fig = plt.figure(figsize=(15, 8.4), facecolor=BG)
gs = gridspec.GridSpec(1, 2, width_ratios=[2.8, 1.85], wspace=0.04)
ax = fig.add_subplot(gs[0])
axt = fig.add_subplot(gs[1], sharey=ax)
for a in (ax, axt):
    a.set_facecolor(BG)

ypos = np.arange(len(main))
top = len(main) - 0.5
xmin = min(main["lower95"].min(), -0.05)
xmax = max(main["upper95"].max(), 0.05)
pad = (xmax - xmin) * 0.10
ax.set_xlim(xmin - pad, xmax + pad)
ax.set_ylim(-0.6, top + 0.15)

# (1) 줄 구분선(가는 점선)과 유의한 줄의 옅은 띠: 눈으로 줄을 따라가기 쉽게
for yi, row in zip(ypos, main.itertuples()):
    if row.sig:
        for a in (ax, axt):
            a.axhspan(yi - 0.5, yi + 0.5, color=ACCENT_BAND, zorder=0)
    if yi > 0:
        for a in (ax, axt):
            a.axhline(yi - 0.5, color="#E5E7EB", lw=0.9, zorder=0.5)

# (2) 0 기준선 (효과 없음)
ax.axvline(0, color=INK2, lw=1.3, ls=(0, (4, 3)), zorder=2)

# (3) 다른 모형 추정치: 속이 빈 작은 마름모
other = coef11[coef11["specification"].isin(OTHER_SPECS)]
for yi, row in zip(ypos, main.itertuples()):
    o = other[other["variable"] == row.variable]
    for orow in o.itertuples():
        ax.scatter(orow.beta_pp_per_1sd, yi, marker="D", s=95, facecolor="white",
                   edgecolor=ACCENT if row.sig else MUTED, linewidth=1.8, zorder=4)

# (4) 신뢰구간(굵은 선 + 끝 표시) + 점
for yi, row in zip(ypos, main.itertuples()):
    c = ACCENT if row.sig else MUTED
    ax.plot([row.lower95, row.upper95], [yi, yi], lw=3.2, color=c,
            solid_capstyle="butt", zorder=3)
    for xe in (row.lower95, row.upper95):
        ax.plot([xe, xe], [yi - 0.12, yi + 0.12], lw=3.2, color=c, zorder=3)
    ax.scatter(row.beta_pp_per_1sd, yi, s=300 if row.sig else 220, color=c,
               edgecolor="white", linewidth=2.0, zorder=5)

# (5) y축 이름: 큰 이름 + 작은 설명
ax.set_yticks(ypos, [""] * len(ypos))
ax.tick_params(axis="y", length=0)
for yi, row in zip(ypos, main.itertuples()):
    name, desc = NAMES[row.variable]
    ax.annotate(name, xy=(0, yi), xycoords=("axes fraction", "data"), xytext=(-18, 6),
                textcoords="offset points", ha="right", va="bottom",
                fontsize=FS_NAME, fontweight="bold", color=ACCENT if row.sig else INK2)
    ax.annotate(desc, xy=(0, yi), xycoords=("axes fraction", "data"), xytext=(-18, -5),
                textcoords="offset points", ha="right", va="top",
                fontsize=FS_DESC, color=MUTED)

# (6) x축
ax.tick_params(axis="x", labelsize=FS_TICK, colors=INK2, width=1.0, length=5)
ax.set_xlabel("변수가 1표준편차 커질 때 다음 분기 폐업률의 변화 (%p)",
              fontsize=FS_TICK + 1, color=INK2, labelpad=10)
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(INK2)
ax.text(0.0, -0.45, "← 폐업률 감소   ", ha="right", va="center", fontsize=FS_DESC, color=MUTED)
ax.text(0.0, -0.45, "   폐업률 증가 →", ha="left", va="center", fontsize=FS_DESC, color=MUTED)

# 패널 라벨 a
ax.text(-0.29, top + 0.62, "a", transform=ax.get_yaxis_transform(), clip_on=False,
        fontsize=FS_PANEL, fontweight="bold", color=INK2, ha="left", va="bottom")
ax.text(0.0, top + 0.1, "효과 없음 (0)", ha="center", va="bottom",
        fontsize=FS_DESC, color=INK2)

# ------------------------------------------------------------
# 3. 오른쪽 b: 학술지식 3선 표 (위·제목 아래·맨 아래에만 가로줄)
# ------------------------------------------------------------
axt.set_xlim(0, 1)
axt.axis("off")
cols = [(0.13, "효과 (%p)"), (0.49, "95% 신뢰구간"), (0.86, "p값")]
head_y = top + 0.1
for xc, head in cols:
    axt.text(xc, head_y, head, ha="center", va="bottom",
             fontsize=FS_TABLE, fontweight="bold", color=INK2)
axt.plot([0.0, 1.0], [top + 0.58, top + 0.58], color=INK2, lw=1.6, clip_on=False)   # 맨 위 굵은 줄
axt.plot([0.0, 1.0], [top + 0.02, top + 0.02], color=INK2, lw=0.9, clip_on=False)   # 제목 아래 줄
axt.plot([0.0, 1.0], [-0.5, -0.5], color=INK2, lw=1.6, clip_on=False)               # 맨 아래 굵은 줄
axt.text(0.0, top + 0.62, "b", fontsize=FS_PANEL, fontweight="bold", color=INK2,
         ha="left", va="bottom", clip_on=False)

for yi, row in zip(ypos, main.itertuples()):
    c = ACCENT if row.sig else INK2
    w = "bold" if row.sig else "normal"
    axt.text(0.13, yi, f"{row.beta_pp_per_1sd:+.3f}", ha="center", va="center",
             fontsize=FS_TABLE, color=c, fontweight=w)
    axt.text(0.49, yi, f"{row.lower95:+.3f} ~ {row.upper95:+.3f}", ha="center", va="center",
             fontsize=FS_TABLE - 1, color=c, fontweight=w)
    axt.text(0.86, yi, p_text(row.p_value), ha="center", va="center",
             fontsize=FS_TABLE, color=c, fontweight=w)

# ------------------------------------------------------------
# 4. 제목, 범례, 주석
# ------------------------------------------------------------
fig.text(0.03, 0.965, "엄격히 통제해도 남는 위험 신호는 ‘고객층 집중도’ 하나",
         ha="left", va="top", fontsize=FS_TITLE, fontweight="bold", color=INK2)
sub = "상권×업종 고정효과 + 분기 고정효과 패널 회귀"
if n_obs and n_area:
    sub += f"  |  관측치 {n_obs:,}개 · 상권 {n_area:,}개"
fig.text(0.03, 0.912, sub, ha="left", va="top", fontsize=FS_SUB, color=MUTED)

legend_items = [
    Line2D([0], [0], marker="o", color=ACCENT, lw=3, markerfacecolor=ACCENT,
           markeredgecolor="white", markersize=13, label="본 모형 추정치와 95% 신뢰구간"),
    Line2D([0], [0], marker="D", color="none", markerfacecolor="white", markeredgecolor=ACCENT,
           markeredgewidth=1.8, markersize=9, label="다른 모형 추정치 (기본 구조 · 시간길이 보정)"),
    Line2D([0], [0], marker="o", color=MUTED, lw=3, markerfacecolor=MUTED,
           markeredgecolor="white", markersize=11, label="95% 신뢰구간이 0을 포함 (효과 확인 안 됨)"),
]
fig.legend(handles=legend_items, loc="lower left", bbox_to_anchor=(0.03, 0.045),
           frameon=False, fontsize=FS_NOTE + 1, ncol=3, handletextpad=0.5, columnspacing=1.8)

fig.text(0.03, 0.008,
         "신뢰구간: 상권 단위 군집 표준오차. 각 변수는 1표준편차로 표준화했고 매출 규모(로그)·점포 수(로그)·연령 정보 비율을 함께 통제함. "
         "관측자료의 조건부 관계이며 인과효과가 아님.",
         ha="left", va="bottom", fontsize=FS_NOTE, color=MUTED)

fig.subplots_adjust(left=0.215, right=0.975, top=0.76, bottom=0.21)

# ------------------------------------------------------------
# 5. 저장 + ZIP 다시 만들기
# ------------------------------------------------------------
png11 = OUT / "figures" / "11_panel_coefficients.png"
pdf11 = OUT / "figures" / "11_panel_coefficients.pdf"
fig.savefig(png11, dpi=FIG_DPI, bbox_inches="tight", pad_inches=0.3, facecolor=BG)
fig.savefig(pdf11, dpi=FIG_DPI, bbox_inches="tight", pad_inches=0.3, facecolor=BG)
fig.savefig(pdf11.with_suffix('.svg'), dpi=FIG_DPI, bbox_inches="tight", pad_inches=0.3, facecolor=BG)
plt.show()
plt.close(fig)

with Image.open(png11) as im:
    print("그림 11 저장 완료:", png11.name, "| 해상도:", im.info.get("dpi"), "| 크기:", im.size)

archive_v2 = OUT.parent / f"{OUT.name}_v2.zip"
with zipfile.ZipFile(archive_v2, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path in OUT.rglob("*"):
        if path.is_file():
            z.write(path, arcname=path.relative_to(OUT))
with zipfile.ZipFile(archive_v2) as z:
    if z.testzip() is not None:
        raise RuntimeError("ZIP 검사에서 문제가 발견됐어요.")
print("새 결과 ZIP:", archive_v2.name)

try:
    from google.colab import files
    files.download(str(archive_v2))
except ImportError:
    print("결과 ZIP 위치:", archive_v2)
